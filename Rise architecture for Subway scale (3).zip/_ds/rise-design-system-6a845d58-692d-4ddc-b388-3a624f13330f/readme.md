# RISE Design System

**RISE** is the operations and analytics workspace for Subway franchisees — a desktop web app where a multi-restaurant owner-operator starts their day, sees what changed, and is told the single most valuable thing to do next. Its distinguishing idea is that the product has an opinion: almost every chart carries a **RISE Bot** takeaway that names an observation *and* an instruction, and every takeaway can be interrogated (Ask RISE), exported, or discussed with a teammate in-place.

The system is a **Subway-branded shadcn/ui theme** — Radix primitives, `class-variance-authority` variants, Tailwind tokens as HSL channel triplets — plus a set of RISE-specific analytics compounds layered on top. Warm neutrals, one brand green, yellow strictly as an accent, quiet uncoloured shadows, and no decoration that isn't carrying information.

## Products / surfaces represented

| Surface | What it is | Status in this design system |
|---|---|---|
| **RISE Home** | The landing page: the "next right thing" hero, a key-metrics grid with portfolio benchmarking, and a filterable To Do list of recommended actions. | Full UI kit — `ui_kits/rise-home/` |
| **RISE Insights** | The reporting area. Five reports live in the rail: Flash Report, Weekly P&L, Labor Summary, Loss Prevention, and a user's own build-it-yourself dashboard. | Full UI kit of the Flash Report — `ui_kits/rise-insights/`; the other four are scaffolded, as in the source |
| Restaurant / Orders / Menu / Inventory / Operations / Team | The rest of the product's nav tree. Present in the rail, no screens built in the prototype. | Nav model only (`RISE_CATEGORIES`) — no screens invented |

There is no marketing site, mobile app, docs site or slide template in the provided sources, so this design system contains none of those. Native (React Native) is mentioned in the source docs as implementing "the current semantic subset only"; nothing native was provided to recreate.

## Sources this was built from

Everything here was read from a mounted local folder — **`desktop/`** — attached read-only to this project. Store these references in case the reader has access:

- `desktop/DESIGN_SYSTEM.md` — a 513-line living spec of the RISE design system (tokens, atoms, compounds, a11y, open gaps). The primary source of truth for this design system; its section numbering is referenced below.
- `desktop/DESIGN_SYSTEM.html`, `desktop/ds-gallery.jsx` — a browsable gallery of the same.
- `desktop/rise-ui.jsx` — the shared kit: token consumers, shadcn primitives, `Rail` / `Topbar` / `Shell`, `MiniCalendar`, brand marks.
- `desktop/rise-flash.jsx` — Flash Report and the app-level compounds (`Panel`, `CommentSheet`, `AskModal`, `MultiFilterChip`, `Controls`, `Kpi`, `Donut`, `LineChart`) plus the four other reports.
- `desktop/rise-shadcn-home.jsx` — Home (`KpiTile`, `RankCard`, `KpiSheet`, `InsightCard`, `TaskRow`, the To Do list).
- `desktop/RISE Homepage.html`, `desktop/RISE Flash Report.html` — the page shells that carry the canonical `:root` token block, the Tailwind theme mapping and the import map.
- `desktop/assets/subway-logo.svg`, `subway-logo-mono.svg` — copied to `assets/`.
- `desktop/screenshots/`, `desktop/uploads/` — ~90 reference screenshots of the built product; used only as a visual cross-check, never as the source for a recreation.

Production code referenced in `DESIGN_SYSTEM.md` but **not** provided: `libs/shared/tokens`, `libs/shared/ui-web` (`@rise/ui-web`), `libs/integration/reporting/ui-web` (`@rise/integration-reporting-ui-web`), and the Storybook compositions. Where the prototype and the production libraries could differ, the prototype is what is recreated here.

---

## CONTENT FUNDAMENTALS

RISE writes like a good general manager standing next to you: it states the number, then tells you what to do about it. Nothing hedges, nothing celebrates.

**Voice: second person, imperative.** The reader is "you"; the product is "RISE" in the third person, never "I" or "we" (the one exception is the Ask RISE chat, where the assistant answers as "I"). Copy addresses the operator's decision, not the data's existence.

- ✅ "Move one Sun-evening closer shift to Fri 5–8pm to match demand."
- ✅ "Put your strongest artist on the 11am–1pm rush — your highest-leverage hour."
- ❌ "Sunday sales were lower than average." (observation with no instruction)

**The takeaway formula: observation → instruction.** One sentence of fact with a real number, then one sentence telling the operator what to change. Takeaways clamp to two lines on the card, so they are written to fit.

> "3PD is 16.6% of sales; after ~30% fees that's ~$790 net. Nudge guests to in-app pickup to recover margin."
> "Corrections are at 6 today — above your warning threshold of 5. One clerk accounts for 4 of them; review the whole-order corrections log for the 6–8pm shift."
> "Produce is 42% of waste ($420). Switch to twice-daily prep counts on tomatoes & lettuce to cut ~$120/wk."

**Money is always named.** Recommendations are justified in dollars or points, with a tilde for estimates: "Saves ~$48 today", "+$0.18 / footlong · +$2.4k/wk", "~$1.7k/day upside", "est. +$3.1k/wk". Approximation is signalled honestly (`~`, "roughly", "about") rather than hidden behind false precision.

**Every delta names its basis.** Never a bare percentage: "↑ 3.2% **vs. 12WA**", "+11% **vs target**", "28 hrs over **schedule**", "#2 **of 9**". The comparison basis is a first-class part of the sentence.

**Casing.** Title Case for page titles, report names and card titles ("Flash Report", "Daypart Breakdown", "Cash Reconciliation", "Add-on Attach Trend"). Sentence case for everything else — blurbs, takeaways, table cells, menu items, buttons ("Send home", "Place order", "Opt in", "Mark done", "Review"). Eyebrows are UPPERCASE at 11px with wide tracking ("INSIGHTS", "HERE'S WHAT WE'RE SEEING", "SUPPORTING EVIDENCE", "WORKSPACE").

**Task titles are imperative verb phrases** with the scope in parentheses or after a middle dot: "Reorder tomatoes (14 cases)", "Send Anna home (labor over)", "Fill opening shift at #1146", "Approve new pricing recs · 6 restaurants".

**Buttons are the verb of the row**, 1–2 words, sentence case: Review · Opt in · Send home · Fill shift · Place order · Nudge team · Confirm order · $343.00.

**Middle dots (·) carry structure everywhere** — they join scope, impact and time into one line: "Saves ~$48 today · #1208 Stamford", "Metric · Today", "Sales & share of day", "14 cases · 7 restaurants". Em dashes carry the pivot inside a sentence; RISE never uses parenthetical asides for emphasis.

**Restaurant naming.** Locations are "restaurants", never "stores" in user-facing copy (the codebase still says `store` internally). They read as `#4421 Hartford`, `#1208 Stamford`, or as street addresses for the two flagship examples; portfolios read as "All 14 restaurants", "NYC Portfolio", "CT East · 6 restaurants".

**Empty and honest states say what to do next.** "No comments yet — start the thread." · "No to-dos match your filters / Try clearing a filter or switching to All." · "This report is next in the build queue. Flash Report is live — pick it from the Insights nav."

**AI attribution is explicit and modest.** The bot is labelled "RISE" + a 9px uppercase `Bot` badge, with "recommended action · 2 min ago" as timing. Confidence is stated as a number ("Confidence 92%") and consequences are spelled out ("Without this order, 5 of 7 restaurants would stock out by Thu lunch"). Suggested questions are written as the operator would ask them: "Why did this change vs. last week?", "Which restaurants drove it?", "What should I do about it?"

**No emoji anywhere in product UI.** No exclamation marks. No "Oops". No congratulation copy — the closest the system comes to praise is a factual "Top quartile" or "The combo prompt is doing its job; keep it on."

---

## VISUAL FOUNDATIONS

### Colour
One brand green does all the work: **`--primary` `145 100% 27%` (#008A38)** carries chrome, primary buttons, active nav, links, focus rings, the insight accent and the primary chart series. **`--brand-yellow` `46 100% 50%` (#FFC700)** is an accent only — badges, the trophy chip, one segment of the footlong meter — and never a button fill; keep it under ~10% of a surface. **`--destructive` `9 74% 45%`** is a *warm* red for variance, alerts, over/short and unfavourable deltas.

Neutrals are deliberately **warm, never cool grey**: canvas `40 33% 99%`, muted `40 18% 95%`, hairlines `40 12% 84%`, text `0 0% 10%`. The app frame (rail, topbar) sits on `--background`; the scrolling `<main>` sits on `--muted` so white `--card` surfaces read as raised. There are no dedicated success/warning/info tokens — success reuses `--primary`, warning reuses yellow or destructive (a documented gap in the source spec).

Colour is stored as **HSL channel triplets** and consumed as `hsl(var(--token))`, which is what makes `/opacity` suffixes (`hsl(var(--primary) / .05)`) the system's whole tinting mechanism: `accent` for insight, `destructive/5` for alert, `brand-yellow/5` for warning, `muted/40` for inset panels, `muted/70` for row hover.

Data-viz has its own palettes and never borrows UI chrome colours: a six-step daypart ramp (green → yellow → blue → orange → purple → teal), a four-step channel ramp, and `--chart-neutral 210 10% 62%` for "Other". Teammate avatars use a three-colour categorical set (`--avatar-1/2/3`); the signed-in user is always green.

### Type
**HK Grotesk** for everything, one family, no display/text pairing (no binaries were provided — see the note at the end). Weights 500–800 do all the work; **800 (extrabold) with `-0.025em` tracking** is the signature — every page title, KPI value, card title and stat is extrabold and tight. Italic is reserved for exactly one thing: the **RISE** wordmark.

The working scale is 26 (page h1) · 24 (KPI value) · 18 (dialog title) · 16 (card section) · 15 (insight headline) · 14 (body/controls) · 13 (insight text, comments, tables) · 12 (legends, chips) · 11 (uppercase eyebrow, KPI label) · 10.5 (rail header, ⌘K) · 9 (Bot/AI badges). Every aligned number is `tabular-nums` — KPIs, legends, tables, currency, deltas.

### Layout
A fixed 232px rail + a 56px topbar + a scrolling main. Inside main, one centred **1180px** content column with `22px / 30px / 40px` padding and a **16px** gap between sections. KPI rows are a 4-column grid (2 up to 768px) with `auto-rows: 1fr` and a 10px gap; chart rows are 2-up or hero+side (3 columns, hero spanning 2) with `items-stretch` so cards match height and the insight card can pin to the bottom with `margin-top: auto`. The rail does **not** collapse — RISE is desktop-only today; there is no mobile layout to copy.

Spacing runs on a 4px base, but 6 and 10 appear as often as 8 and 12. Container padding is 24px for general cards, **18px** for analytics panels and the Home cards, 12px for tiles and insight cards.

### Backgrounds and imagery
Flat colour only. **No photography, no illustration, no gradient mesh, no texture, no pattern, no full-bleed imagery anywhere in the product.** The only gradients in the entire system are two, both functional: the 135° green→yellow split of the brand mark (`--gradient-mark`) and the left-to-right `primary → primary-dark` ramp behind the Ask RISE header (`--gradient-brand`). The Home hero is solid `--primary`, not a gradient. The only photographic content is teammate avatar photos.

### Corners, borders, cards
Everything derives from `--radius: 8px`: 4px menu items and small chips · **6px buttons, inputs, badges, rail rows** · 8px KPI tiles, tabs track, scaffold frames · **12px cards, insight cards, dialogs** · 16px chat bubbles and the Ask RISE modal · pill for avatars, send buttons, status dots and the footlong meter.

A card is: 12px radius, **1px `--border` hairline**, white `--card` fill, `--shadow`. That's it — no coloured left border, no gradient fill, no double border. Tinted cards swap the fill and the edge together (`--accent` + `primary/20`, `destructive/5` + `destructive/30`, `yellow/5` + `yellow/50`). Dividers are single 1px `--border` lines; inside the insight card the action row divider drops to `rgba(0,0,0,.05)` so it doesn't fight the tint.

### Elevation
Quiet and uncoloured, the Tailwind ladder: `shadow-sm` for outline buttons, inputs and select triggers · `shadow` for cards and the primary button · `shadow-md` for menus, selects and popovers · `shadow-lg` for dialogs and kit sheets · `shadow-2xl` for the two bespoke overlays (Ask RISE, comment sheet). The brand mark adds an `inset 0 0 0 1px rgba(0,0,0,.06)` hairline instead of a shadow. Emphasis comes from tint, not from lifting things higher.

### Motion, hover, press, focus
Tailwind defaults, nothing bespoke: ~150ms colour transitions, **200ms** for the two overlay enters (opacity + translate for the slide-over, opacity + scale for the modal). No named easing tokens exist; no bounces, no springs, no entrance animation on page content.

- **Hover** darkens or tints: primary fills go to `/90`, secondary to `/80`, ghost/outline pick up `--accent`, rows pick up `muted/70`, rail rows `accent/50`.
- **Press** goes one step further (`/80`, `/70`, `accent/70`) **and scales to 0.97** — that 3% squeeze is the system's tactile signature.
- **Focus** is a single 1px ring in `--ring` (= primary). Never a 2px halo, never a glow.
- **Disabled** is `opacity: .5` plus `pointer-events: none`.
- Loading is `animate-pulse` skeletons in `--muted`. The only other animation in the product is the three staggered bouncing dots (0.15s apart) while Ask RISE is thinking.
- Hover *reveals* in one place only: To Do row checkboxes fade in on row hover.

### Transparency and blur
Opacity is used constantly for tints and states; **blur exactly once** — the Ask RISE modal backdrop is `rgba(0,0,0,.6)` with a 4px blur. Dialog and sheet backdrops are flat `black/50` and `black/40`. There are no frosted panels, no protection gradients over imagery (there is no imagery), and no translucent chrome.

### Charts
Hand-built SVG, no chart library. A 2.5px solid `--primary` line with 3.5px dots against a 1.5px `5 5` dashed comparison at 45% opacity; donuts are a 132px ring at 13px stroke (16px on hover) with a 1.5° gap so segments never overlap at the seam, showing Total in the centre until you hover a segment. Legends are fixed-width tabular columns — name · value · % · Δ — with ↑/↓ text arrows coloured green/red. Every chart tooltip is the same 6px-radius `--popover` card with `--shadow-md`.

---

## ICONOGRAPHY

**One icon set: [lucide](https://lucide.dev), pinned to 0.454.** The prototype uses `lucide-react@0.454.0`; this design system loads the identical geometry from the vanilla lucide UMD build on CDN and renders it through an `Icon` wrapper, so nothing is redrawn by hand.

```html
<script src="https://unpkg.com/lucide@0.454.0/dist/umd/lucide.js"></script>
```

- **Sizes**: 12 (chip chevrons, delta arrows) · 14 (filter chips, small buttons) · **16 = the default** (menus, buttons, actions) · 18 (rail rows) · 20–24 (empty states, alert banners). Stroke is lucide's default 2px; RISE never re-weights it.
- **Colour**: decorative icons inherit `--muted-foreground`; active/meaningful icons take `currentColor` from their button. Icons inside a green fill are white.
- **Icons in constant use**: `Home`, `Inbox`, `BarChart3`, `Store`, `ShoppingBag`, `UtensilsCrossed`, `Boxes`, `Activity`, `Users`, `CircleHelp`, `Search`, `CalendarDays`, `Clock`, `MapPin`, `ListFilter`, `List`, `ArrowLeftRight`, `Plus`, `X`, `Check`, `ChevronDown`/`ChevronLeft`/`ChevronRight`, `MoveUpRight` (the delta arrow, rotated 90° when negative), `Sparkles`, `Download`, `FileText`, `FileSpreadsheet`, `MessageSquare`, `Send`, `Paperclip`, `UserPlus`, `Share2`, `MoreHorizontal`, `TriangleAlert`, `Trophy`, `LineChart`, `CalendarClock`, `Calculator`, `SearchX`, `CircleCheck`, `ArrowRight`, `ArrowUp`.
- **No emoji in product UI, ever.** Unicode *is* used as typography in three specific places: the ↑ / ↓ arrows in `Trend` and chart legends, the ▲ / ▼ markers in benchmark deltas, and the `·` middle dot as a structural separator. The `⌘K` glyph appears in the search hint.
- **Custom marks — two, and only two.** `BrandMark`: a rounded square (radius = size / 3.6) split 135° green→yellow with an inset hairline, the app logo, paired with the italic "RISE" wordmark. `SparkMark`: the same square carrying a white filled 4-point star — the canonical RISE AI identity. **Always use `SparkMark` for AI**, never a lucide `Sparkles` in its place. Both are drawn from the source's own geometry.
- The alert identity is a white `TriangleAlert` on a solid `--destructive` rounded square, which replaces the `SparkMark` in warn-tone insight cards.

### Brand assets
`assets/subway-logo.svg` and `assets/subway-logo-mono.svg` were copied verbatim from `desktop/assets/`. Note that the RISE prototype itself **never renders these files** — the product identifies itself with `BrandMark` + the italic RISE wordmark. Treat the Subway marks as parent-brand assets for co-branded contexts, and use the RISE lockup inside the product. No logo was drawn, reconstructed or invented here.

---

## Index

### Root
| File | What it is |
|---|---|
| `styles.css` | The one file consumers link. Nothing but `@import` lines. |
| `readme.md` | This document. |
| `SKILL.md` | Agent-Skills front matter so this folder works as a Claude Code skill. |
| `thumbnail.html` | The homepage tile for this design system. |
| `tokens/` | `fonts.css` · `colors.css` · `typography.css` · `spacing.css` · `radius.css` · `shadows.css` · `motion.css` · `semantic.css` · `base.css` |
| `assets/` | `subway-logo.svg`, `subway-logo-mono.svg` |
| `guidelines/` | 18 foundation specimen cards (Colors · Type · Spacing · Foundations) shown in the Design System tab |
| `components/` | The component library, grouped below |
| `ui_kits/` | `rise-home/` and `rise-insights/` — full interactive recreations |
| `templates/` | `rise-home/` and `rise-insights-report/` — starting folders a consuming project can copy |

### Components
Everything is exported on the bundle namespace and consumed as `const { Button } = window.<Namespace>`.

- **`components/core/`** — `Icon`, `Button`, `Input`, `Badge`, `Checkbox`, `Avatar`, `Separator`, `Skeleton`, `Eyebrow`
- **`components/brand/`** — `BrandMark` (+ `BrandLockup`), `SparkMark`
- **`components/surfaces/`** — `Card` (+ `CardContent`), `Panel`, `InsightCard`, `NextRightThing`, `PageHead`, `ScaffoldFrame`
- **`components/controls/`** — `Select`, `Tabs`, `MultiFilterChip`, `GroupByChip`, `MiniCalendar`, `CustomDateButton`, `FilterBar`
- **`components/overlays/`** — `Dialog` (+ `DialogHeader`/`DialogTitle`/`DialogDescription`), `Sheet` (+ `SheetHeader`/`SheetBody`/`SheetFooter`), `DropdownMenu` (+ `DropdownMenuItem`/`DropdownMenuLabel`), `AskModal`, `CommentSheet`
- **`components/data/`** — `Kpi`, `Delta`, `Trend`, `Donut`, `LineChart` (+ `ChartLegend`), `StackedMeter`, `RankCard`, `TaskRow`
- **`components/navigation/`** — `Shell` (+ `PageContainer`), `Rail` (+ `RailRow`/`RailChild`, `RISE_REPORTS`, `RISE_CATEGORIES`), `Topbar`, `StorePicker` (+ `RISE_STORE_GROUPS`)

Each directory has a `@dsCard` HTML showing its states, and each component has a `.d.ts` props contract and a `.prompt.md` with a usage example.

### Component inventory notes
The list above **is** the source's inventory (`DESIGN_SYSTEM.md` §3–4 plus the three JSX files), not a generic starter set. Mapping of renames:

- `Kpi` / `KpiTile` (the source has both, identical) → one `Kpi`.
- The source's `Avatar` / `AvatarImage` / `AvatarFallback` trio → one `Avatar` with `initials` + `src`.
- The source's `Controls` (Insights filter row) → `FilterBar`.
- The footlong meter → `StackedMeter`.
- The Home `Hero` → `NextRightThing`, after its eyebrow.
- Radix-backed primitives (`Dialog`, `Sheet`, `DropdownMenu`, `Select`, `Tabs`, `Checkbox`, `Avatar`, `Separator`) are re-implemented as plain React with identical visuals, since this design system ships no npm dependencies. They keep the source's classes' exact geometry and states; they do **not** reproduce Radix's full a11y behaviour (focus trapping, typeahead, arrow-key navigation) — see Known gaps.

**Intentional additions** (not in the source, added with reason):
- `Icon` — a wrapper over the lucide set, so consumers get the real glyphs without an npm import.
- `BrandLockup` — the mark + italic wordmark pairing that the source assembles inline in the rail; extracted so it can't drift.
- `ChartLegend` — the solid-dot/dashed-line legend repeated under every `LineChart` in the source.
- `PageContainer` — the 1180px content column repeated verbatim on every page.
- `SheetHeader` / `SheetBody` / `SheetFooter` — the header/scroll/footer split the source's bespoke sheets share.

### UI kits
| Kit | Entry | Covers |
|---|---|---|
| `ui_kits/rise-home/` | `index.html` | Hero, key metrics + benchmark, To Do with filters/grouping/bulk actions, metric sheet, task sheet with the order flow |
| `ui_kits/rise-insights/` | `index.html` | Page head + export menu, live filter bar, KPI row, 8 chart panels with insight cards, Ask RISE, comment sheet, report switching + scaffolds |

Both are recreations of the provided prototype, not new designs.

### Templates
Copyable starting folders, offered to consuming projects in the template picker. Each is a single Design Component plus a `ds-base.js` whose one `base` line points at this design system.

| Template | Entry | What you get | Tweaks |
|---|---|---|---|
| **RISE Home** | `templates/rise-home/RiseHome.dc.html` | Shell + rail/topbar, the next-right-thing hero, the key-metrics grid with benchmark card, and a grouped To Do list | `compareTo` (myself / region / system), `showBenchmark` |
| **RISE Insights report** | `templates/rise-insights-report/RiseInsightsReport.dc.html` | Shell + page head, KPI row, and four chart panels each carrying a RISE takeaway | `basis` (12WA / Prior / PY), `showComparison`, `alertTone` |

To use one in a consuming project, copy the folder and change `const base = '../..'` in `ds-base.js` to the bound `_ds/<folder>` path.

---

## Known gaps (carried forward from the source spec)

These are the source system's own open questions, reproduced here rather than papered over: no semantic success/warning/info tokens; no error state on `Input` and no loading state on `Button`; no mobile/responsive rail; two overlay shadow levels (`lg` and `2xl`) coexisting; the bespoke overlays and filter popovers lacking Radix-parity a11y (roles, focus trap, arrow keys); no `aria-current` on the active rail row; charts having no text/table alternative; and `--muted-foreground` at 42% lightness on `--muted` needing a WCAG AA contrast check for small text.

## Fonts — needs your input

**No HK Grotesk binaries were provided.** The source spec lists "approved HK Grotesk assets" as deferred, so `tokens/fonts.css` declares no `@font-face` and `--font-sans` reads `"HK Grotesk", ui-sans-serif, system-ui, sans-serif` — the documented system-font fallback the production implementation also uses. No substitute family is loaded, so specimens and screens currently render in the platform sans; weights (500–800) and the tight tracking still apply, but proportions will shift once the real face lands.

**Please upload the licensed HK Grotesk woff2 files.** Drop them in `assets/fonts/` and add the `@font-face` rules to `tokens/fonts.css` (400/500/600/700/800 plus the italic used by the RISE wordmark). Nothing else in the system changes.
