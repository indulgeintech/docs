/* @ds-bundle: {"format":4,"namespace":"RISEDesignSystem_6a845d","components":[{"name":"BrandMark","sourcePath":"components/brand/BrandMark.jsx"},{"name":"BrandLockup","sourcePath":"components/brand/BrandMark.jsx"},{"name":"SparkMark","sourcePath":"components/brand/SparkMark.jsx"},{"name":"CustomDateButton","sourcePath":"components/controls/CustomDateButton.jsx"},{"name":"FilterBar","sourcePath":"components/controls/FilterBar.jsx"},{"name":"GroupByChip","sourcePath":"components/controls/GroupByChip.jsx"},{"name":"MiniCalendar","sourcePath":"components/controls/MiniCalendar.jsx"},{"name":"MultiFilterChip","sourcePath":"components/controls/MultiFilterChip.jsx"},{"name":"Select","sourcePath":"components/controls/Select.jsx"},{"name":"Tabs","sourcePath":"components/controls/Tabs.jsx"},{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Checkbox","sourcePath":"components/core/Checkbox.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Separator","sourcePath":"components/core/Separator.jsx"},{"name":"Skeleton","sourcePath":"components/core/Skeleton.jsx"},{"name":"Delta","sourcePath":"components/data/Delta.jsx"},{"name":"Donut","sourcePath":"components/data/Donut.jsx"},{"name":"Kpi","sourcePath":"components/data/Kpi.jsx"},{"name":"LineChart","sourcePath":"components/data/LineChart.jsx"},{"name":"ChartLegend","sourcePath":"components/data/LineChart.jsx"},{"name":"RankCard","sourcePath":"components/data/RankCard.jsx"},{"name":"StackedMeter","sourcePath":"components/data/StackedMeter.jsx"},{"name":"TaskRow","sourcePath":"components/data/TaskRow.jsx"},{"name":"Trend","sourcePath":"components/data/Trend.jsx"},{"name":"RISE_REPORTS","sourcePath":"components/navigation/Rail.jsx"},{"name":"RISE_CATEGORIES","sourcePath":"components/navigation/Rail.jsx"},{"name":"RailRow","sourcePath":"components/navigation/Rail.jsx"},{"name":"RailChild","sourcePath":"components/navigation/Rail.jsx"},{"name":"Rail","sourcePath":"components/navigation/Rail.jsx"},{"name":"Shell","sourcePath":"components/navigation/Shell.jsx"},{"name":"PageContainer","sourcePath":"components/navigation/Shell.jsx"},{"name":"RISE_STORE_GROUPS","sourcePath":"components/navigation/StorePicker.jsx"},{"name":"StorePicker","sourcePath":"components/navigation/StorePicker.jsx"},{"name":"Topbar","sourcePath":"components/navigation/Topbar.jsx"},{"name":"AskModal","sourcePath":"components/overlays/AskModal.jsx"},{"name":"CommentSheet","sourcePath":"components/overlays/CommentSheet.jsx"},{"name":"Dialog","sourcePath":"components/overlays/Dialog.jsx"},{"name":"DialogHeader","sourcePath":"components/overlays/Dialog.jsx"},{"name":"DialogTitle","sourcePath":"components/overlays/Dialog.jsx"},{"name":"DialogDescription","sourcePath":"components/overlays/Dialog.jsx"},{"name":"DropdownMenu","sourcePath":"components/overlays/DropdownMenu.jsx"},{"name":"DropdownMenuItem","sourcePath":"components/overlays/DropdownMenu.jsx"},{"name":"DropdownMenuLabel","sourcePath":"components/overlays/DropdownMenu.jsx"},{"name":"Sheet","sourcePath":"components/overlays/Sheet.jsx"},{"name":"SheetHeader","sourcePath":"components/overlays/Sheet.jsx"},{"name":"SheetBody","sourcePath":"components/overlays/Sheet.jsx"},{"name":"SheetFooter","sourcePath":"components/overlays/Sheet.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"CardContent","sourcePath":"components/surfaces/Card.jsx"},{"name":"InsightCard","sourcePath":"components/surfaces/InsightCard.jsx"},{"name":"NextRightThing","sourcePath":"components/surfaces/NextRightThing.jsx"},{"name":"PageHead","sourcePath":"components/surfaces/PageHead.jsx"},{"name":"Panel","sourcePath":"components/surfaces/Panel.jsx"},{"name":"ScaffoldFrame","sourcePath":"components/surfaces/ScaffoldFrame.jsx"}],"sourceHashes":{"components/brand/BrandMark.jsx":"b8222c5a5233","components/brand/SparkMark.jsx":"d1a41be5303a","components/controls/CustomDateButton.jsx":"e27729ef79c3","components/controls/FilterBar.jsx":"22c1aacf2624","components/controls/GroupByChip.jsx":"8504a9c89524","components/controls/MiniCalendar.jsx":"9271c7cdc022","components/controls/MultiFilterChip.jsx":"2e1fbb8f76ef","components/controls/Select.jsx":"336f779c4b9b","components/controls/Tabs.jsx":"b2277c256309","components/core/Avatar.jsx":"90937f48f662","components/core/Badge.jsx":"407fbf4e2ce0","components/core/Button.jsx":"1793190c53c9","components/core/Checkbox.jsx":"3f93e71dba3b","components/core/Eyebrow.jsx":"1af46d01363c","components/core/Icon.jsx":"26de60efffe9","components/core/Input.jsx":"c741d0577462","components/core/Separator.jsx":"141dab3c63b8","components/core/Skeleton.jsx":"b6673e8f8412","components/data/Delta.jsx":"8033b7230153","components/data/Donut.jsx":"4d132b4a1967","components/data/Kpi.jsx":"2480dd01cf97","components/data/LineChart.jsx":"c034d89255f5","components/data/RankCard.jsx":"6f2a98a76b8a","components/data/StackedMeter.jsx":"77a3d8f44e1d","components/data/TaskRow.jsx":"870bfe235722","components/data/Trend.jsx":"3775f287e9a1","components/navigation/Rail.jsx":"5221060e3164","components/navigation/Shell.jsx":"0ad12aa73139","components/navigation/StorePicker.jsx":"524e4e9f883f","components/navigation/Topbar.jsx":"d5c305dda5e7","components/overlays/AskModal.jsx":"75512d770662","components/overlays/CommentSheet.jsx":"3fed7495e6f6","components/overlays/Dialog.jsx":"a89e71e966d1","components/overlays/DropdownMenu.jsx":"424d9fdaa5de","components/overlays/Sheet.jsx":"a6f0c314aee2","components/surfaces/Card.jsx":"874616b5c04f","components/surfaces/InsightCard.jsx":"caa70244f221","components/surfaces/NextRightThing.jsx":"e0dd1d821b97","components/surfaces/PageHead.jsx":"68213be9fd02","components/surfaces/Panel.jsx":"f1801b51f9ad","components/surfaces/ScaffoldFrame.jsx":"792ffb415396","ui_kits/rise-home/HomeScreen.jsx":"1a0d16999bf6","ui_kits/rise-home/data.js":"69cc930cc9eb","ui_kits/rise-insights/FlashReport.jsx":"491b0e41bb1a","ui_kits/rise-insights/InsightsScreen.jsx":"dac3ce59bd95","ui_kits/rise-insights/data.js":"1fcc6568bab5"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.RISEDesignSystem_6a845d = window.RISEDesignSystem_6a845d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/BrandMark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function BrandMark({
  size = 22,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true",
    style: {
      width: size,
      height: size,
      borderRadius: size / 3.6,
      display: "inline-block",
      flexShrink: 0,
      background: "var(--gradient-mark)",
      boxShadow: "var(--shadow-hairline)",
      ...style
    }
  }, rest));
}
function BrandLockup({
  size = 22,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(BrandMark, {
    size: size
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 800,
      fontStyle: "italic",
      letterSpacing: "var(--tracking-tight)",
      fontSize: Math.round(size * 0.68),
      color: "hsl(var(--foreground))"
    }
  }, "RISE"));
}
Object.assign(__ds_scope, { BrandMark, BrandLockup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/BrandMark.jsx", error: String((e && e.message) || e) }); }

// components/brand/SparkMark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SparkMark({
  size = 20,
  invert = false,
  style,
  ...rest
}) {
  const glyph = Math.round(size * 0.55);
  return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true",
    style: {
      width: size,
      height: size,
      borderRadius: Math.round(size * 0.22),
      flexShrink: 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: invert ? "linear-gradient(135deg,#fff 0 50%, hsl(var(--brand-yellow)) 50% 100%)" : "var(--gradient-mark)",
      boxShadow: invert ? "inset 0 0 0 1px rgba(0,0,0,.08)" : "none",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: glyph,
    height: glyph,
    viewBox: "0 0 24 24",
    fill: invert ? "hsl(var(--primary))" : "#fff"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 2l2.4 6.6L21 11l-6.6 2.4L12 20l-2.4-6.6L3 11l6.6-2.4z"
  })));
}
Object.assign(__ds_scope, { SparkMark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/SparkMark.jsx", error: String((e && e.message) || e) }); }

// components/controls/Tabs.jsx
try { (() => {
function Tabs({
  value,
  onChange,
  items = [],
  size = "default",
  style
}) {
  const h = size === "sm" ? 32 : 36;
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      height: h,
      borderRadius: "var(--radius-lg)",
      background: "hsl(var(--muted))",
      padding: 4,
      color: "hsl(var(--muted-foreground))",
      gap: 2,
      ...style
    }
  }, items.map(([k, label]) => {
    const on = k === value;
    return /*#__PURE__*/React.createElement("button", {
      key: k,
      type: "button",
      role: "tab",
      "aria-selected": on,
      onMouseDown: e => e.preventDefault(),
      onClick: () => onChange && onChange(k),
      style: {
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 6,
        whiteSpace: "nowrap",
        borderRadius: "var(--radius-md)",
        padding: "4px 12px",
        border: 0,
        height: h - 8,
        fontFamily: "var(--font-sans)",
        fontSize: 12,
        fontWeight: 600,
        cursor: "pointer",
        background: on ? "hsl(var(--background))" : "transparent",
        color: on ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground))",
        boxShadow: on ? "var(--shadow)" : "none",
        transition: "all var(--duration-fast) var(--ease-default)"
      }
    }, label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Avatar({
  initials,
  src,
  alt,
  size = 32,
  color,
  style,
  ...rest
}) {
  const [failed, setFailed] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      height: size,
      width: size,
      flexShrink: 0,
      overflow: "hidden",
      borderRadius: "var(--radius-full)",
      background: color || "hsl(var(--primary))",
      color: "hsl(var(--primary-foreground))",
      fontFamily: "var(--font-sans)",
      fontSize: Math.max(8, Math.round(size * 0.375)),
      fontWeight: 700,
      lineHeight: 1,
      userSelect: "none",
      ...style
    }
  }, rest), src && !failed ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt || initials || "",
    onError: () => setFailed(true),
    style: {
      height: "100%",
      width: "100%",
      objectFit: "cover",
      aspectRatio: "1 / 1"
    }
  }) : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const BADGE = {
  default: {
    background: "hsl(var(--primary))",
    color: "hsl(var(--primary-foreground))",
    borderColor: "transparent"
  },
  secondary: {
    background: "hsl(var(--secondary))",
    color: "hsl(var(--secondary-foreground))",
    borderColor: "transparent"
  },
  outline: {
    background: "transparent",
    color: "hsl(var(--foreground))",
    borderColor: "hsl(var(--border))"
  },
  yellow: {
    background: "hsl(var(--brand-yellow))",
    color: "hsl(var(--foreground))",
    borderColor: "transparent"
  },
  destructive: {
    background: "hsl(var(--destructive))",
    color: "hsl(var(--destructive-foreground))",
    borderColor: "transparent"
  }
};
function Badge({
  variant = "default",
  style,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      borderRadius: "var(--radius-md)",
      border: "1px solid",
      padding: "2px 10px",
      fontFamily: "var(--font-sans)",
      fontSize: 12,
      fontWeight: 600,
      lineHeight: 1.4,
      whiteSpace: "nowrap",
      ...(BADGE[variant] || BADGE.default),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  default: {
    height: 36,
    padding: "8px 16px",
    fontSize: 14
  },
  sm: {
    height: 32,
    padding: "0 12px",
    fontSize: 12
  },
  lg: {
    height: 40,
    padding: "0 32px",
    fontSize: 14
  },
  icon: {
    height: 36,
    width: 36,
    padding: 0,
    fontSize: 14
  }
};
const VARIANTS = {
  default: {
    rest: {
      background: "hsl(var(--primary))",
      color: "hsl(var(--primary-foreground))",
      boxShadow: "var(--shadow)",
      border: "1px solid transparent"
    },
    hover: {
      background: "hsl(var(--primary) / .9)"
    },
    press: {
      background: "hsl(var(--primary) / .8)"
    }
  },
  destructive: {
    rest: {
      background: "hsl(var(--destructive))",
      color: "hsl(var(--destructive-foreground))",
      boxShadow: "var(--shadow-sm)",
      border: "1px solid transparent"
    },
    hover: {
      background: "hsl(var(--destructive) / .9)"
    },
    press: {
      background: "hsl(var(--destructive) / .8)"
    }
  },
  outline: {
    rest: {
      background: "hsl(var(--background))",
      color: "hsl(var(--foreground))",
      border: "1px solid hsl(var(--input))",
      boxShadow: "var(--shadow-sm)"
    },
    hover: {
      background: "hsl(var(--accent))",
      color: "hsl(var(--accent-foreground))"
    },
    press: {
      background: "hsl(var(--accent) / .7)"
    }
  },
  secondary: {
    rest: {
      background: "hsl(var(--secondary))",
      color: "hsl(var(--secondary-foreground))",
      boxShadow: "var(--shadow-sm)",
      border: "1px solid transparent"
    },
    hover: {
      background: "hsl(var(--secondary) / .8)"
    },
    press: {
      background: "hsl(var(--secondary) / .7)"
    }
  },
  ghost: {
    rest: {
      background: "transparent",
      color: "hsl(var(--foreground))",
      border: "1px solid transparent"
    },
    hover: {
      background: "hsl(var(--accent))",
      color: "hsl(var(--accent-foreground))"
    },
    press: {
      background: "hsl(var(--accent) / .7)"
    }
  },
  link: {
    rest: {
      background: "transparent",
      color: "hsl(var(--primary))",
      border: "1px solid transparent",
      padding: 0,
      height: "auto"
    },
    hover: {
      textDecoration: "underline",
      textUnderlineOffset: 4
    },
    press: {}
  }
};
function Button({
  variant = "default",
  size = "default",
  disabled,
  style,
  children,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const [focus, setFocus] = React.useState(false);
  const v = VARIANTS[variant] || VARIANTS.default;
  const s = SIZES[size] || SIZES.default;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    onFocus: e => setFocus(e.target.matches(":focus-visible")),
    onBlur: () => setFocus(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      whiteSpace: "nowrap",
      borderRadius: "var(--radius-md)",
      fontFamily: "var(--font-sans)",
      fontWeight: 500,
      lineHeight: 1,
      cursor: disabled ? "not-allowed" : "pointer",
      transition: "all var(--duration-fast) var(--ease-default)",
      ...s,
      ...v.rest,
      ...(hover && !disabled ? v.hover : null),
      ...(press && !disabled ? v.press : null),
      transform: press && !disabled ? "scale(var(--press-scale))" : "none",
      outline: focus ? "1px solid hsl(var(--ring))" : "none",
      outlineOffset: 0,
      opacity: disabled ? 0.5 : 1,
      pointerEvents: disabled ? "none" : "auto",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Eyebrow({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 11,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "hsl(var(--muted-foreground))",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
// RISE uses lucide (the same set as the prototype's lucide-react, pinned 0.454.0).
// The vanilla lucide UMD build must be on the page:
//   <script src="https://unpkg.com/lucide@0.454.0/dist/umd/lucide.js"></script>
// Geometry comes straight from lucide's own icon nodes — nothing is hand-drawn here.
const toPascal = n => String(n).replace(/(^\w|[-_ ]\w)/g, m => m.replace(/[-_ ]/, "").toUpperCase());
function Icon({
  name,
  size = 16,
  strokeWidth = 2,
  color = "currentColor",
  style,
  className,
  title
}) {
  const set = typeof window !== "undefined" && window.lucide && window.lucide.icons || null;
  const node = set ? set[toPascal(name)] || set[name] : null;
  const box = {
    width: size,
    height: size,
    display: "inline-block",
    flexShrink: 0,
    verticalAlign: "middle"
  };
  if (!node) return /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    className: className,
    style: {
      ...box,
      ...style
    }
  });
  const children = (Array.isArray(node) ? node[2] : []) || [];
  return /*#__PURE__*/React.createElement("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    className: className,
    style: {
      ...box,
      ...style
    },
    "aria-hidden": title ? undefined : "true",
    role: title ? "img" : undefined
  }, title ? /*#__PURE__*/React.createElement("title", null, title) : null, children.map(([tag, attrs], i) => React.createElement(tag, {
    key: i,
    ...attrs
  })));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/controls/GroupByChip.jsx
try { (() => {
function GroupByChip({
  value,
  onChange,
  options = [],
  label = "Group by",
  icon = "List",
  style
}) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const h = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);
  const cur = (options.find(([k]) => k === value) || ["", "None"])[1];
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      height: 32,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--card))",
      fontSize: 12,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setOpen(o => !o),
    "aria-expanded": open,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      padding: "0 10px",
      height: "100%",
      border: 0,
      background: "none",
      font: "inherit",
      cursor: "pointer",
      borderRadius: "var(--radius-md)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    color: "hsl(var(--muted-foreground))"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "hsl(var(--muted-foreground))"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      color: "hsl(var(--foreground))"
    }
  }, cur), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "ChevronDown",
    size: 12,
    color: "hsl(var(--muted-foreground))"
  })), open ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 4px)",
      right: 0,
      zIndex: 30,
      width: 176,
      borderRadius: "var(--radius-lg)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--popover))",
      boxShadow: "var(--shadow-md)",
      overflow: "hidden",
      padding: "4px 0"
    }
  }, options.map(([k, l]) => /*#__PURE__*/React.createElement(GroupOption, {
    key: k,
    label: l,
    on: k === value,
    onPick: () => {
      onChange && onChange(k);
      setOpen(false);
    }
  }))) : null);
}
function GroupOption({
  label,
  on,
  onPick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onPick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      width: "100%",
      alignItems: "center",
      gap: 8,
      padding: "6px 10px",
      border: 0,
      textAlign: "left",
      font: "inherit",
      fontSize: 14,
      cursor: "pointer",
      background: hover ? "hsl(var(--accent))" : "transparent"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      height: 16,
      width: 16,
      display: "grid",
      placeItems: "center",
      flexShrink: 0
    }
  }, on ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Check",
    size: 14,
    color: "hsl(var(--primary))"
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, label));
}
Object.assign(__ds_scope, { GroupByChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/GroupByChip.jsx", error: String((e && e.message) || e) }); }

// components/controls/MiniCalendar.jsx
try { (() => {
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const sameDay = (a, b) => a && b && a.toDateString() === b.toDateString();
function MiniCalendar({
  onSelect,
  style
}) {
  const today = new Date();
  const [view, setView] = React.useState({
    y: today.getFullYear(),
    m: today.getMonth()
  });
  const [range, setRange] = React.useState({
    start: null,
    end: null
  });
  const startDow = new Date(view.y, view.m, 1).getDay();
  const days = new Date(view.y, view.m + 1, 0).getDate();
  const shift = n => setView(v => {
    const d = new Date(v.y, v.m + n, 1);
    return {
      y: d.getFullYear(),
      m: d.getMonth()
    };
  });
  const pick = day => {
    const d = new Date(view.y, view.m, day);
    setRange(r => {
      const nr = !r.start || r.end ? {
        start: d,
        end: null
      } : d < r.start ? {
        start: d,
        end: r.start
      } : {
        start: r.start,
        end: d
      };
      if (nr.start && nr.end && onSelect) onSelect(nr);
      return nr;
    });
  };
  const inRange = d => range.start && range.end && d >= range.start && d <= range.end;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 248,
      userSelect: "none",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 4px 8px"
    }
  }, /*#__PURE__*/React.createElement(NavBtn, {
    dir: "ChevronLeft",
    onClick: () => shift(-1)
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 600
    }
  }, MONTHS[view.m], " ", view.y), /*#__PURE__*/React.createElement(NavBtn, {
    dir: "ChevronRight",
    onClick: () => shift(1)
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(7,1fr)",
      gap: 2,
      textAlign: "center"
    }
  }, ["S", "M", "T", "W", "T", "F", "S"].map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      fontSize: 10,
      fontWeight: 600,
      color: "hsl(var(--muted-foreground))",
      padding: "4px 0"
    }
  }, d)), Array.from({
    length: startDow
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: "e" + i
  })), Array.from({
    length: days
  }).map((_, i) => {
    const day = i + 1,
      d = new Date(view.y, view.m, day);
    return /*#__PURE__*/React.createElement(Day, {
      key: day,
      day: day,
      end: sameDay(d, range.start) || sameDay(d, range.end),
      within: inRange(d),
      today: sameDay(d, today),
      onPick: () => pick(day)
    });
  })));
}
function NavBtn({
  dir,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      height: 28,
      width: 28,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      border: 0,
      borderRadius: "var(--radius-md)",
      background: hover ? "hsl(var(--accent))" : "transparent",
      cursor: "pointer",
      color: "inherit"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: dir,
    size: 16
  }));
}
function Day({
  day,
  end,
  within,
  today,
  onPick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onPick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      height: 32,
      border: 0,
      borderRadius: "var(--radius-md)",
      fontFamily: "var(--font-sans)",
      fontSize: 12,
      fontWeight: 500,
      cursor: "pointer",
      background: end ? "hsl(var(--primary))" : within ? "hsl(var(--accent))" : hover ? "hsl(var(--accent))" : "transparent",
      color: end ? "hsl(var(--primary-foreground))" : within ? "hsl(var(--accent-foreground))" : "hsl(var(--foreground))",
      boxShadow: today && !end ? "inset 0 0 0 1px hsl(var(--border))" : "none",
      transition: "background var(--duration-fast) var(--ease-default)"
    }
  }, day);
}
Object.assign(__ds_scope, { MiniCalendar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/MiniCalendar.jsx", error: String((e && e.message) || e) }); }

// components/controls/CustomDateButton.jsx
try { (() => {
const fmtD = d => d.toLocaleDateString(undefined, {
  month: "short",
  day: "numeric"
});
function CustomDateButton({
  active,
  onPick,
  style
}) {
  const [open, setOpen] = React.useState(false);
  const [label, setLabel] = React.useState("Custom");
  const [hover, setHover] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const h = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setOpen(o => !o),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      height: 32,
      borderRadius: "var(--radius-md)",
      padding: "0 12px",
      fontFamily: "var(--font-sans)",
      fontSize: 12,
      fontWeight: 600,
      cursor: "pointer",
      border: "1px solid " + (active ? "hsl(var(--primary) / .5)" : "hsl(var(--input))"),
      background: active || hover ? "hsl(var(--accent))" : "transparent",
      color: active ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground))",
      transition: "all var(--duration-fast) var(--ease-default)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "CalendarDays",
    size: 14
  }), label), open ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 4px)",
      right: 0,
      zIndex: 50,
      padding: 8,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--popover))",
      boxShadow: "var(--shadow-md)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.MiniCalendar, {
    onSelect: r => {
      setLabel(fmtD(r.start) + " – " + fmtD(r.end));
      setOpen(false);
      onPick && onPick(r);
    }
  })) : null);
}
Object.assign(__ds_scope, { CustomDateButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/CustomDateButton.jsx", error: String((e && e.message) || e) }); }

// components/controls/MultiFilterChip.jsx
try { (() => {
function MultiFilterChip({
  label,
  icon,
  options = [],
  selected = [],
  onChange,
  onRemove,
  size = "xs",
  style
}) {
  const [open, setOpen] = React.useState(false);
  const [q, setQ] = React.useState("");
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const h = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);
  const h = size === "sm" ? 32 : 28;
  const shown = options.filter(([, l]) => l.toLowerCase().includes(q.toLowerCase()));
  const toggle = k => onChange && onChange(selected.includes(k) ? selected.filter(x => x !== k) : [...selected, k]);
  const value = selected.length === 0 ? "All" : selected.length === 1 ? (options.find(([k]) => k === selected[0]) || ["", ""])[1] : selected.length + " selected";
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      height: h,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--card))",
      fontSize: 12,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setOpen(o => !o),
    "aria-expanded": open,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      padding: onRemove ? "0 6px 0 10px" : "0 10px",
      height: "100%",
      border: 0,
      background: "none",
      font: "inherit",
      cursor: "pointer",
      borderRadius: onRemove ? "var(--radius-md) 0 0 var(--radius-md)" : "var(--radius-md)"
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    color: "hsl(var(--muted-foreground))"
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "hsl(var(--muted-foreground))"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      maxWidth: 120,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      color: selected.length ? "hsl(var(--foreground))" : "inherit"
    }
  }, value), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "ChevronDown",
    size: 12,
    color: "hsl(var(--muted-foreground))"
  })), onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onRemove,
    "aria-label": "Remove " + label + " filter",
    style: {
      padding: "0 6px",
      height: "100%",
      border: 0,
      borderLeft: "1px solid hsl(var(--border))",
      background: "none",
      cursor: "pointer",
      color: "hsl(var(--muted-foreground))",
      borderRadius: "0 var(--radius-md) var(--radius-md) 0",
      display: "inline-flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "X",
    size: 12
  })) : null, open ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 4px)",
      left: 0,
      zIndex: 30,
      width: 240,
      borderRadius: "var(--radius-lg)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--popover))",
      boxShadow: "var(--shadow-md)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 8,
      borderBottom: "1px solid hsl(var(--border))"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      height: 28,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--background))",
      padding: "0 8px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Search",
    size: 14,
    color: "hsl(var(--muted-foreground))"
  }), /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Search " + label.toLowerCase() + "…",
    style: {
      flex: 1,
      minWidth: 0,
      background: "transparent",
      border: 0,
      outline: "none",
      font: "inherit",
      fontSize: 12
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "6px 10px",
      borderBottom: "1px solid hsl(var(--border))",
      fontSize: 11
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => onChange && onChange(options.map(([k]) => k)),
    style: {
      border: 0,
      background: "none",
      padding: 0,
      cursor: "pointer",
      font: "inherit",
      fontWeight: 600,
      color: "hsl(var(--primary))"
    }
  }, "Select all"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => onChange && onChange([]),
    style: {
      border: 0,
      background: "none",
      padding: 0,
      cursor: "pointer",
      font: "inherit",
      color: "hsl(var(--muted-foreground))"
    }
  }, "Clear all")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 208,
      overflow: "auto",
      padding: "4px 0"
    }
  }, shown.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px",
      fontSize: 12,
      color: "hsl(var(--muted-foreground))",
      textAlign: "center"
    }
  }, "No matches") : null, shown.map(([k, l]) => /*#__PURE__*/React.createElement(FilterOption, {
    key: k,
    label: l,
    on: selected.includes(k),
    onPick: () => toggle(k)
  })))) : null);
}
function FilterOption({
  label,
  on,
  onPick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onPick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      width: "100%",
      alignItems: "center",
      gap: 8,
      padding: "6px 10px",
      border: 0,
      textAlign: "left",
      font: "inherit",
      fontSize: 14,
      cursor: "pointer",
      background: hover ? "hsl(var(--accent))" : "transparent",
      color: "inherit"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      height: 16,
      width: 16,
      borderRadius: "var(--radius-sm)",
      display: "grid",
      placeItems: "center",
      flexShrink: 0,
      border: "1px solid " + (on ? "hsl(var(--primary))" : "hsl(var(--input))"),
      background: on ? "hsl(var(--primary))" : "transparent",
      color: "hsl(var(--primary-foreground))"
    }
  }, on ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Check",
    size: 12
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, label));
}
Object.assign(__ds_scope, { MultiFilterChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/MultiFilterChip.jsx", error: String((e && e.message) || e) }); }

// components/controls/Select.jsx
try { (() => {
const HEIGHTS = {
  default: 36,
  sm: 32,
  xs: 28
};
function Select({
  value,
  onChange,
  options = [],
  icon,
  size = "default",
  placeholder = "Select…",
  style,
  menuAlign = "start"
}) {
  const [open, setOpen] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const h = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);
  const current = options.find(([k]) => k === value);
  const h = HEIGHTS[size] || HEIGHTS.default;
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setOpen(o => !o),
    "aria-expanded": open,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 6,
      height: h,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--input))",
      background: hover ? "hsl(var(--muted) / .6)" : "hsl(var(--card))",
      padding: size === "default" ? "0 12px" : "0 10px",
      fontFamily: "var(--font-sans)",
      fontSize: size === "default" ? 14 : 12,
      fontWeight: 600,
      color: "hsl(var(--foreground))",
      boxShadow: size === "default" ? "var(--shadow-sm)" : "none",
      cursor: "pointer",
      whiteSpace: "nowrap",
      transition: "background var(--duration-fast) var(--ease-default)"
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    color: "hsl(var(--muted-foreground))"
  }) : null, /*#__PURE__*/React.createElement("span", null, current ? current[1] : placeholder), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "ChevronDown",
    size: 16,
    style: {
      opacity: 0.5
    }
  })), open ? /*#__PURE__*/React.createElement("div", {
    role: "listbox",
    style: {
      position: "absolute",
      top: "calc(100% + 4px)",
      [menuAlign === "end" ? "right" : "left"]: 0,
      zIndex: 50,
      minWidth: "100%",
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--popover))",
      color: "hsl(var(--popover-foreground))",
      boxShadow: "var(--shadow-md)",
      padding: 4,
      overflow: "hidden"
    }
  }, options.map(([k, label]) => /*#__PURE__*/React.createElement(SelectItem, {
    key: k,
    label: label,
    selected: k === value,
    onPick: () => {
      onChange && onChange(k);
      setOpen(false);
    }
  }))) : null);
}
function SelectItem({
  label,
  selected,
  onPick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "option",
    "aria-selected": selected,
    onClick: onPick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      display: "flex",
      width: "100%",
      alignItems: "center",
      borderRadius: "var(--radius-sm)",
      border: 0,
      padding: "6px 32px 6px 8px",
      textAlign: "left",
      font: "inherit",
      fontSize: 14,
      fontWeight: 500,
      cursor: "pointer",
      whiteSpace: "nowrap",
      background: hover ? "hsl(var(--accent))" : "transparent",
      color: hover ? "hsl(var(--accent-foreground))" : "hsl(var(--popover-foreground))"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, label), selected ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 8,
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Check",
    size: 16
  })) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/Select.jsx", error: String((e && e.message) || e) }); }

// components/controls/FilterBar.jsx
try { (() => {
function FilterBar({
  date,
  onDateChange,
  dateOptions = [],
  filterDefs = {},
  applied = [],
  values = {},
  onAdd,
  onRemove,
  onValuesChange,
  groupBy,
  onGroupByChange,
  groupByOptions = [],
  compare,
  onCompareChange,
  compareOptions = [],
  style
}) {
  const [addOpen, setAddOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!addOpen) return;
    const h = e => {
      if (ref.current && !ref.current.contains(e.target)) setAddOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [addOpen]);
  const avail = Object.keys(filterDefs).filter(k => !applied.includes(k));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 12,
      borderBottom: "1px solid hsl(var(--border))",
      paddingBottom: 10,
      marginTop: -4,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      flexWrap: "wrap",
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Select, {
    value: date,
    onChange: onDateChange,
    options: dateOptions,
    icon: "CalendarDays",
    size: "xs"
  }), applied.map(k => {
    const def = filterDefs[k] || {};
    return /*#__PURE__*/React.createElement(__ds_scope.MultiFilterChip, {
      key: k,
      label: def.label || k,
      icon: def.icon,
      options: def.options || [],
      selected: values[k] || [],
      onChange: arr => onValuesChange && onValuesChange(k, arr),
      onRemove: () => onRemove && onRemove(k)
    });
  }), avail.length > 0 ? /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setAddOpen(o => !o),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      height: 28,
      borderRadius: "var(--radius-md)",
      border: "1px dashed hsl(var(--border))",
      background: "transparent",
      padding: "0 8px",
      fontFamily: "var(--font-sans)",
      fontSize: 12,
      fontWeight: 500,
      cursor: "pointer",
      color: "hsl(var(--muted-foreground))"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Plus",
    size: 14
  }), "Add filter"), addOpen ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 4px)",
      left: 0,
      zIndex: 40,
      minWidth: 176,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--popover))",
      boxShadow: "var(--shadow-md)",
      padding: 4
    }
  }, avail.map(k => /*#__PURE__*/React.createElement(AddRow, {
    key: k,
    def: filterDefs[k],
    onPick: () => {
      onAdd && onAdd(k);
      setAddOpen(false);
    }
  }))) : null) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      flexShrink: 0,
      paddingTop: 2
    }
  }, groupByOptions.length ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "hsl(var(--muted-foreground))"
    }
  }, "Group by"), /*#__PURE__*/React.createElement(__ds_scope.Select, {
    value: groupBy,
    onChange: onGroupByChange,
    options: groupByOptions,
    icon: "List",
    size: "xs",
    menuAlign: "end"
  })) : null, compareOptions.length ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "hsl(var(--muted-foreground))"
    }
  }, "Compare to"), /*#__PURE__*/React.createElement(__ds_scope.Select, {
    value: compare,
    onChange: onCompareChange,
    options: compareOptions,
    icon: "ArrowLeftRight",
    size: "xs",
    menuAlign: "end"
  })) : null));
}
function AddRow({
  def,
  onPick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onPick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      width: "100%",
      alignItems: "center",
      gap: 8,
      borderRadius: "var(--radius-sm)",
      border: 0,
      padding: "6px 8px",
      font: "inherit",
      fontSize: 14,
      cursor: "pointer",
      background: hover ? "hsl(var(--accent))" : "transparent",
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: def.icon,
    size: 16,
    color: "hsl(var(--muted-foreground))"
  }), def.label);
}
Object.assign(__ds_scope, { FilterBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/FilterBar.jsx", error: String((e && e.message) || e) }); }

// components/core/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  checked,
  onCheckedChange,
  disabled,
  tone = "primary",
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const on = !!checked;
  const fill = tone === "neutral" ? "hsl(var(--foreground))" : "hsl(var(--primary))";
  const edge = tone === "neutral" ? "hsl(var(--input))" : "hsl(var(--primary))";
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "checkbox",
    "aria-checked": on,
    disabled: disabled,
    onClick: e => {
      e.stopPropagation();
      onCheckedChange && onCheckedChange(!on);
    },
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      height: 16,
      width: 16,
      flexShrink: 0,
      borderRadius: "var(--radius-sm)",
      padding: 0,
      border: "1px solid " + (on ? fill : edge),
      background: on ? fill : "transparent",
      color: on ? tone === "neutral" ? "hsl(var(--background))" : "hsl(var(--primary-foreground))" : "transparent",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: disabled ? "not-allowed" : "pointer",
      boxShadow: tone === "neutral" ? "none" : "var(--shadow)",
      outline: focus ? "1px solid hsl(var(--ring))" : "none",
      opacity: disabled ? 0.5 : 1,
      transition: "background var(--duration-fast) var(--ease-default), opacity var(--duration-fast)",
      ...style
    }
  }, rest), on ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Check",
    size: 14
  }) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  style,
  disabled,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("input", _extends({
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      display: "flex",
      height: 36,
      width: "100%",
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--input))",
      background: "transparent",
      padding: "4px 12px",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "hsl(var(--foreground))",
      boxShadow: focus ? "var(--shadow-sm), 0 0 0 1px hsl(var(--ring))" : "var(--shadow-sm)",
      outline: "none",
      transition: "box-shadow var(--duration-fast) var(--ease-default)",
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/Separator.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Separator({
  orientation = "horizontal",
  style,
  ...rest
}) {
  const h = orientation === "horizontal";
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "separator",
    "aria-orientation": orientation,
    style: {
      flexShrink: 0,
      background: "hsl(var(--border))",
      height: h ? 1 : "100%",
      width: h ? "100%" : 1,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Separator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Separator.jsx", error: String((e && e.message) || e) }); }

// components/core/Skeleton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Skeleton({
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, "@keyframes rise-pulse{0%,100%{opacity:1}50%{opacity:.5}}"), /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderRadius: "var(--radius-md)",
      background: "hsl(var(--muted))",
      animation: "rise-pulse 2s cubic-bezier(.4,0,.6,1) infinite",
      ...style
    }
  }, rest)));
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/data/Delta.jsx
try { (() => {
const clean = s => String(s).replace(/[▲▼]/g, "").trim();
const isNeg = s => /^[−-]/.test(clean(s));
const isNeutral = s => /on target|^0\.0$|^0$/.test(clean(s));
function Delta({
  value,
  dir = "up",
  good,
  size = "sm",
  style
}) {
  const neutral = isNeutral(value);
  const negative = isNeg(value);
  const favorable = neutral ? null : good !== undefined ? good : dir === "up" ? !negative : negative;
  const color = favorable === null ? "hsl(var(--muted-foreground))" : favorable ? "hsl(var(--primary))" : "hsl(var(--destructive))";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 2,
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      fontSize: size === "lg" ? 14 : 11,
      color,
      ...style
    }
  }, neutral ? null : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "MoveUpRight",
    size: 12,
    style: {
      transform: negative ? "rotate(90deg)" : "none"
    }
  }), clean(value));
}
Object.assign(__ds_scope, { Delta });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Delta.jsx", error: String((e && e.message) || e) }); }

// components/data/Donut.jsx
try { (() => {
const usd = n => "$" + n.toLocaleString(undefined, {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});
function Donut({
  data = [],
  format = usd,
  style
}) {
  const [hi, setHi] = React.useState(null);
  const total = data.reduce((s, d) => s + d[1], 0) || 1;
  const R = 42,
    C = 2 * Math.PI * R;
  let acc = 0;
  const sel = hi != null ? data[hi] : null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 20,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 132,
      height: 132,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 100",
    style: {
      width: "100%",
      height: "100%",
      transform: "rotate(-90deg)"
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "50",
    cy: "50",
    r: R,
    fill: "none",
    stroke: "hsl(var(--muted))",
    strokeWidth: "13"
  }), data.map(([name, v, color], i) => {
    const len = v / total * C,
      off = acc;
    acc += len;
    const seg = Math.max(len - 1.5, 0.01);
    return /*#__PURE__*/React.createElement("circle", {
      key: i,
      cx: "50",
      cy: "50",
      r: R,
      fill: "none",
      stroke: color,
      strokeWidth: hi === i ? 16 : 13,
      strokeDasharray: seg + " " + (C - seg),
      strokeDashoffset: -off,
      style: {
        cursor: "pointer",
        transition: "stroke-width .1s"
      },
      onMouseEnter: () => setHi(i),
      onMouseLeave: () => setHi(null)
    }, /*#__PURE__*/React.createElement("title", null, name + ": " + format(v) + " (" + (v / total * 100).toFixed(1) + "%)"));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      textAlign: "center",
      pointerEvents: "none",
      padding: "0 12px"
    }
  }, sel ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 800,
      fontVariantNumeric: "tabular-nums",
      lineHeight: 1
    }
  }, (sel[1] / total * 100).toFixed(0), "%"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: "hsl(var(--muted-foreground))",
      maxWidth: 88,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      marginTop: 2
    }
  }, sel[0])) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: "hsl(var(--muted-foreground))",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)"
    }
  }, "Total"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      lineHeight: 1.2
    }
  }, format(total))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      flex: 1,
      minWidth: 0
    }
  }, data.map(([name, v, color, delta], i) => /*#__PURE__*/React.createElement("div", {
    key: name,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      fontSize: 12
    },
    onMouseEnter: () => setHi(i),
    onMouseLeave: () => setHi(null)
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: "var(--radius-sm)",
      flexShrink: 0,
      background: color
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontWeight: 500,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "hsl(var(--muted-foreground))",
      fontVariantNumeric: "tabular-nums",
      textAlign: "right",
      width: 64,
      whiteSpace: "nowrap"
    }
  }, format(v)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      width: 44,
      textAlign: "right"
    }
  }, (v / total * 100).toFixed(0), "%"), delta ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 56,
      textAlign: "right",
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      whiteSpace: "nowrap",
      color: String(delta).indexOf("↓") === 0 ? "hsl(var(--destructive))" : "hsl(var(--primary))"
    }
  }, delta) : null))));
}
Object.assign(__ds_scope, { Donut });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Donut.jsx", error: String((e && e.message) || e) }); }

// components/data/Kpi.jsx
try { (() => {
function Kpi({
  label,
  value,
  dir = "up",
  mag,
  good,
  onClick,
  style
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const Tag = onClick ? "button" : "div";
  return /*#__PURE__*/React.createElement(Tag, {
    type: onClick ? "button" : undefined,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      borderRadius: "var(--radius-lg)",
      border: "1px solid hsl(var(--border))",
      background: press ? "hsl(var(--muted))" : hover && onClick ? "hsl(var(--muted) / .7)" : "hsl(var(--card))",
      padding: 12,
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      gap: 6,
      textAlign: "left",
      minWidth: 0,
      fontFamily: "var(--font-sans)",
      color: "hsl(var(--foreground))",
      cursor: onClick ? "pointer" : "default",
      transition: "background var(--duration-fast) var(--ease-default)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: "hsl(var(--muted-foreground))",
      lineHeight: 1.2
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 800,
      letterSpacing: "var(--tracking-tight)",
      fontVariantNumeric: "tabular-nums",
      lineHeight: 1
    }
  }, value), mag ? /*#__PURE__*/React.createElement(__ds_scope.Delta, {
    value: mag,
    dir: dir,
    good: good
  }) : null);
}
Object.assign(__ds_scope, { Kpi });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Kpi.jsx", error: String((e && e.message) || e) }); }

// components/data/LineChart.jsx
try { (() => {
const usd = n => "$" + n.toLocaleString(undefined, {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});
function LineChart({
  series = [],
  comparison = [],
  labels = [],
  dates,
  basis = "12WA",
  format = usd,
  style
}) {
  const [hi, setHi] = React.useState(null);
  const all = [...series, ...comparison];
  const max = Math.max(...all) * 1.04,
    min = Math.min(...all) * 0.92;
  const W = 560,
    H = 170,
    P = 10;
  const step = (W - 2 * P) / Math.max(series.length - 1, 1);
  const x = i => P + i * step;
  const y = v => H - P - (v - min) / (max - min || 1) * (H - 2 * P);
  const path = arr => arr.map((v, i) => (i ? "L" : "M") + x(i).toFixed(1) + " " + y(v).toFixed(1)).join(" ");
  const d = hi != null && comparison[hi] ? (series[hi] - comparison[hi]) / comparison[hi] * 100 : 0;
  const up = d >= 0;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      ...style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 " + W + " " + H,
    style: {
      width: "100%",
      height: "auto",
      display: "block"
    }
  }, hi != null ? /*#__PURE__*/React.createElement("line", {
    x1: x(hi),
    x2: x(hi),
    y1: P,
    y2: H - P,
    stroke: "hsl(var(--border))",
    strokeWidth: "1"
  }) : null, comparison.length ? /*#__PURE__*/React.createElement("path", {
    d: path(comparison),
    fill: "none",
    stroke: "hsl(var(--muted-foreground))",
    strokeWidth: "1.5",
    strokeDasharray: "5 5",
    opacity: "0.45"
  }) : null, /*#__PURE__*/React.createElement("path", {
    d: path(series),
    fill: "none",
    stroke: "hsl(var(--primary))",
    strokeWidth: "2.5",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }), series.map((v, i) => /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: x(i),
    cy: y(v),
    r: hi === i ? 5 : 3.5,
    fill: "hsl(var(--primary))"
  })), series.map((v, i) => /*#__PURE__*/React.createElement("rect", {
    key: "h" + i,
    x: x(i) - step / 2,
    y: "0",
    width: step,
    height: H,
    fill: "transparent",
    onMouseEnter: () => setHi(i),
    onMouseLeave: () => setHi(null)
  }))), hi != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: x(hi) / W * 100 + "%",
      top: y(series[hi]) / H * 100 + "%",
      transform: "translate(-50%,-115%)",
      pointerEvents: "none",
      zIndex: 10,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--popover))",
      padding: "6px 10px",
      fontSize: 12,
      boxShadow: "var(--shadow-md)",
      whiteSpace: "nowrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600
    }
  }, labels[hi]), dates && dates[hi] ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "hsl(var(--muted-foreground))",
      fontWeight: 500
    }
  }, dates[hi]) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "hsl(var(--primary))",
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums"
    }
  }, format(series[hi])), comparison[hi] != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: "hsl(var(--muted-foreground))",
      fontVariantNumeric: "tabular-nums",
      fontSize: 11
    }
  }, basis, " ", format(comparison[hi])) : null, comparison[hi] != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 2,
      marginTop: 2,
      fontSize: 11,
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      color: up ? "hsl(var(--primary))" : "hsl(var(--destructive))"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "MoveUpRight",
    size: 12,
    style: {
      transform: up ? "none" : "rotate(90deg)"
    }
  }), (up ? "+" : "") + d.toFixed(1) + "% vs. " + basis) : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginTop: 4,
      padding: "0 4px"
    }
  }, labels.map((l, i) => /*#__PURE__*/React.createElement("span", {
    key: l + i,
    style: {
      fontSize: 10,
      color: "hsl(var(--muted-foreground))"
    }
  }, l))));
}
function ChartLegend({
  seriesLabel = "This week",
  comparisonLabel = "12-wk avg",
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      marginTop: 8,
      fontSize: 10.5,
      color: "hsl(var(--muted-foreground))",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: "var(--radius-full)",
      background: "hsl(var(--primary))"
    }
  }), seriesLabel), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      width: 12,
      borderTop: "2px dashed hsl(var(--muted-foreground) / .6)"
    }
  }), comparisonLabel));
}
Object.assign(__ds_scope, { LineChart, ChartLegend });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/LineChart.jsx", error: String((e && e.message) || e) }); }

// components/data/RankCard.jsx
try { (() => {
const quartileLabel = pct => pct >= 75 ? "Top quartile" : pct >= 50 ? "2nd quartile" : pct >= 25 ? "3rd quartile" : "Bottom quartile";
function RankCard({
  percentile,
  move,
  moveGood = true,
  scopeNote,
  ranks = [],
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: "var(--radius-xl)",
      background: "hsl(var(--accent))",
      border: "1px solid hsl(var(--primary) / .15)",
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 10,
      width: 300,
      flexShrink: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22,
      fontWeight: 800,
      letterSpacing: "var(--tracking-tight)",
      whiteSpace: "nowrap",
      color: "hsl(var(--foreground))"
    }
  }, quartileLabel(percentile)), /*#__PURE__*/React.createElement("span", {
    style: {
      height: 36,
      width: 36,
      borderRadius: "var(--radius-full)",
      background: "hsl(var(--brand-yellow))",
      color: "hsl(var(--primary))",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      boxShadow: "var(--shadow-sm)",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Trophy",
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 8,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 700
    }
  }, percentile, "th percentile"), move ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 2,
      fontSize: 14,
      fontWeight: 700,
      color: moveGood ? "hsl(var(--primary))" : "hsl(var(--destructive))"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "MoveUpRight",
    size: 14,
    style: {
      transform: moveGood ? "none" : "rotate(90deg)"
    }
  }), move) : null), scopeNote ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "hsl(var(--muted-foreground))"
    }
  }, scopeNote) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      paddingTop: 10,
      borderTop: "1px solid hsl(var(--primary) / .15)",
      display: "flex",
      gap: 24
    }
  }, ranks.map(([label, rank, of]) => /*#__PURE__*/React.createElement("div", {
    key: label
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "hsl(var(--muted-foreground))"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      marginTop: 2
    }
  }, "#", rank, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "hsl(var(--muted-foreground))",
      fontWeight: 500
    }
  }, "of ", of))))));
}
Object.assign(__ds_scope, { RankCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/RankCard.jsx", error: String((e && e.message) || e) }); }

// components/data/StackedMeter.jsx
try { (() => {
function StackedMeter({
  data = [],
  showLabels = true,
  style
}) {
  const total = data.reduce((s, d) => s + d[1], 0) || 1;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 28,
      borderRadius: "var(--radius-full)",
      overflow: "hidden",
      display: "flex"
    }
  }, data.map(([name, v, color]) => {
    const pct = v / total * 100;
    const dark = color.indexOf("--brand-yellow") === -1 && color.indexOf("--chart-neutral") === -1;
    return /*#__PURE__*/React.createElement("div", {
      key: name,
      title: name + ": " + v + " (" + pct.toFixed(0) + "%)",
      style: {
        width: pct + "%",
        height: "100%",
        background: color,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 11,
        fontWeight: 700,
        whiteSpace: "nowrap",
        overflow: "hidden",
        color: dark ? "hsl(var(--primary-foreground))" : "hsl(var(--foreground))"
      }
    }, showLabels && pct > 12 ? name : "");
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      fontSize: 12
    }
  }, data.map(([name, v, color, delta]) => /*#__PURE__*/React.createElement("div", {
    key: name,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: "var(--radius-sm)",
      flexShrink: 0,
      background: color
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontWeight: 500,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "hsl(var(--muted-foreground))",
      fontVariantNumeric: "tabular-nums",
      width: 48,
      textAlign: "right"
    }
  }, v.toLocaleString()), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      width: 44,
      textAlign: "right"
    }
  }, (v / total * 100).toFixed(0), "%"), delta ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 56,
      textAlign: "right",
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      color: String(delta).indexOf("↓") === 0 ? "hsl(var(--destructive))" : "hsl(var(--primary))"
    }
  }, delta) : null))));
}
Object.assign(__ds_scope, { StackedMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StackedMeter.jsx", error: String((e && e.message) || e) }); }

// components/data/TaskRow.jsx
try { (() => {
function TaskRow({
  title,
  context,
  due,
  hot,
  action,
  assignee,
  assigneePhoto,
  assigneeColor,
  selected,
  bulkMode,
  onToggleSelect,
  onOpen,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onOpen,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      borderRadius: "var(--radius-lg)",
      border: "1px solid hsl(var(--border))",
      padding: "12px 14px",
      cursor: "pointer",
      background: selected ? "hsl(var(--muted))" : hover ? "hsl(var(--muted) / .7)" : "hsl(var(--card))",
      boxShadow: selected ? "inset 0 0 0 1px hsl(var(--border))" : "none",
      transition: "background var(--duration-fast) var(--ease-default)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
    tone: "neutral",
    checked: selected,
    onCheckedChange: onToggleSelect,
    style: {
      opacity: bulkMode || selected || hover ? 1 : 0,
      transition: "opacity var(--duration-fast)"
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    initials: assignee,
    src: assigneePhoto,
    color: assigneeColor,
    size: 32
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: "hsl(var(--foreground))",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "hsl(var(--muted-foreground))",
      marginTop: 2,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, context)), due ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    variant: hot ? "destructive" : "secondary",
    style: {
      fontSize: 10,
      flexShrink: 0
    }
  }, due) : null, action ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    variant: "outline",
    style: {
      flexShrink: 0,
      width: 96,
      justifyContent: "center"
    },
    onClick: e => {
      e.stopPropagation();
      onOpen && onOpen();
    }
  }, action) : null);
}
Object.assign(__ds_scope, { TaskRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/TaskRow.jsx", error: String((e && e.message) || e) }); }

// components/data/Trend.jsx
try { (() => {
function Trend({
  dir = "up",
  mag,
  basis = "12WA",
  good,
  style
}) {
  const positive = good === undefined ? dir === "up" : good;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 2,
      fontSize: 11,
      fontWeight: 700,
      color: positive ? "hsl(var(--primary))" : "hsl(var(--destructive))",
      ...style
    }
  }, dir === "up" ? "↑" : "↓", " ", mag, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "hsl(var(--muted-foreground))",
      fontWeight: 500
    }
  }, "vs. ", basis));
}
Object.assign(__ds_scope, { Trend });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Trend.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Rail.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const RISE_REPORTS = [["flash", "Flash Report"], ["pnl", "Weekly P&L"], ["labor", "Labor Summary"], ["loss", "Loss Prevention"], ["mine", "Maria's Dashboard"]];
const RISE_CATEGORIES = [{
  key: "restaurant",
  icon: "Store",
  label: "Restaurant",
  items: ["Restaurant Groups", "Restaurant Management"]
}, {
  key: "orders",
  icon: "ShoppingBag",
  label: "Orders",
  items: ["Completed Orders", "Future Orders", "Catering"]
}, {
  key: "menu",
  icon: "UtensilsCrossed",
  label: "Menu",
  items: ["Pricing", "Opt In"]
}, {
  key: "inv",
  icon: "Boxes",
  label: "Inventory",
  items: ["Order Ingredients", "Count", "Item Availability", "WISR"]
}, {
  key: "ops",
  icon: "Activity",
  label: "Operations",
  items: ["Guest Sentiment", "Training", "REV"]
}, {
  key: "team",
  icon: "Users",
  label: "Team",
  items: ["Schedule", "Team"]
}];
function RailRow({
  icon,
  label,
  active,
  chevron,
  chevOpen,
  onClick,
  href
}) {
  const [hover, setHover] = React.useState(false);
  const style = {
    display: "flex",
    alignItems: "center",
    gap: 10,
    width: "100%",
    borderRadius: "var(--radius-md)",
    padding: "0 10px",
    height: 32,
    fontFamily: "var(--font-sans)",
    fontSize: 14,
    textAlign: "left",
    border: 0,
    cursor: "pointer",
    textDecoration: "none",
    boxSizing: "border-box",
    background: active ? "hsl(var(--accent))" : hover ? "hsl(var(--accent) / .5)" : "transparent",
    color: active ? "hsl(var(--accent-foreground))" : "hsl(var(--foreground) / .8)",
    fontWeight: active ? 600 : 400,
    transition: "background var(--duration-fast) var(--ease-default)"
  };
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18,
    color: "hsl(var(--muted-foreground))"
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, label), chevron ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "ChevronDown",
    size: 12,
    color: "hsl(var(--muted-foreground))",
    style: {
      transform: chevOpen ? "none" : "rotate(-90deg)",
      transition: "transform var(--duration-fast)"
    }
  }) : null);
  const handlers = {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  };
  if (chevron || !href) return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    style: style
  }, handlers), inner);
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onClick: onClick,
    style: style
  }, handlers), inner);
}
function RailChild({
  label,
  href,
  current,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href || "#",
    onClick: onClick ? e => {
      e.preventDefault();
      onClick();
    } : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "center",
      width: "100%",
      borderRadius: "var(--radius-md)",
      height: 26,
      padding: "0 8px 0 36px",
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      textDecoration: "none",
      boxSizing: "border-box",
      cursor: "pointer",
      background: current ? "hsl(var(--card))" : hover ? "hsl(var(--accent) / .5)" : "transparent",
      color: current ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground))",
      fontWeight: current ? 600 : 400,
      boxShadow: current ? "var(--shadow-sm)" : "none",
      border: current ? "1px solid hsl(var(--border))" : "1px solid transparent",
      transition: "background var(--duration-fast) var(--ease-default)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, label));
}
function Rail({
  active = "home",
  onSelect,
  reports = RISE_REPORTS,
  categories = RISE_CATEGORIES,
  homeHref = "#",
  style
}) {
  const [open, setOpen] = React.useState({
    insights: true
  });
  const toggle = k => setOpen(o => ({
    ...o,
    [k]: !o[k]
  }));
  const insOpen = open.insights !== false;
  const inGroup = reports.some(([k]) => k === active);
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 232,
      flexShrink: 0,
      borderRight: "1px solid hsl(var(--border))",
      background: "hsl(var(--background))",
      display: "flex",
      flexDirection: "column",
      gap: 2,
      padding: "14px 10px",
      overflowY: "auto",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      padding: "0 6px 12px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.BrandLockup, {
    size: 22
  })), /*#__PURE__*/React.createElement(RailRow, {
    icon: "Home",
    label: "Home",
    href: homeHref,
    active: active === "home",
    onClick: onSelect ? () => onSelect("home") : undefined
  }), /*#__PURE__*/React.createElement(RailRow, {
    icon: "Inbox",
    label: "Inbox",
    href: "#"
  }), /*#__PURE__*/React.createElement(__ds_scope.Separator, {
    style: {
      margin: "8px 0"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 8px 4px",
      fontSize: 10.5,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "hsl(var(--muted-foreground) / .8)"
    }
  }, "Workspace"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2,
      background: inGroup ? "hsl(var(--accent))" : "transparent",
      border: "1px solid " + (inGroup ? "hsl(var(--primary) / .15)" : "transparent"),
      borderRadius: "var(--radius-lg)",
      padding: inGroup ? 4 : 0
    }
  }, /*#__PURE__*/React.createElement(RailRow, {
    icon: "BarChart3",
    label: "Insights",
    chevron: true,
    chevOpen: insOpen,
    onClick: () => toggle("insights")
  }), insOpen ? reports.map(([k, label]) => /*#__PURE__*/React.createElement(RailChild, {
    key: k,
    label: label,
    current: active === k,
    onClick: onSelect ? () => onSelect(k) : undefined
  })) : null), categories.map(g => /*#__PURE__*/React.createElement(React.Fragment, {
    key: g.key
  }, /*#__PURE__*/React.createElement(RailRow, {
    icon: g.icon,
    label: g.label,
    chevron: true,
    chevOpen: !!open[g.key],
    onClick: () => toggle(g.key)
  }), open[g.key] ? g.items.map(it => /*#__PURE__*/React.createElement(RailChild, {
    key: it,
    label: it
  })) : null)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(RailRow, {
    icon: "CircleHelp",
    label: "Help",
    href: "#"
  }));
}
Object.assign(__ds_scope, { RISE_REPORTS, RISE_CATEGORIES, RailRow, RailChild, Rail });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Rail.jsx", error: String((e && e.message) || e) }); }

// components/navigation/StorePicker.jsx
try { (() => {
const RISE_STORE_GROUPS = [{
  label: "Restaurant Groups",
  items: ["All 14 restaurants", "NYC Portfolio", "CT Portfolio"]
}, {
  label: "Restaurants",
  items: ["12367 North Hampton Way", "76 Broad St", "#4421 Hartford", "#552 Bridgeport", "#1208 Stamford", "#732 New Haven", "#1146 Bristol", "#118 Waterbury"]
}];
function StorePicker({
  value,
  onChange,
  groups = RISE_STORE_GROUPS,
  style
}) {
  const [open, setOpen] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const [q, setQ] = React.useState("");
  const [internal, setInternal] = React.useState(groups[0].items[0]);
  const store = value !== undefined ? value : internal;
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const h = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);
  const shown = groups.map(g => ({
    label: g.label,
    items: g.items.filter(i => i.toLowerCase().includes(q.toLowerCase()))
  })).filter(g => g.items.length);
  const pick = it => {
    setInternal(it);
    onChange && onChange(it);
    setOpen(false);
    setQ("");
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setOpen(o => !o),
    "aria-expanded": open,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      height: 32,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--input))",
      background: hover ? "hsl(var(--accent))" : "hsl(var(--background))",
      padding: "0 12px",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 600,
      cursor: "pointer",
      boxShadow: "var(--shadow-sm)",
      color: "hsl(var(--foreground))",
      transition: "background var(--duration-fast) var(--ease-default)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "var(--radius-full)",
      background: "hsl(var(--primary))"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      maxWidth: 200,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, store), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "ChevronDown",
    size: 16,
    style: {
      opacity: 0.5
    }
  })), open ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: "calc(100% + 4px)",
      zIndex: 50,
      width: 288,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--popover))",
      color: "hsl(var(--popover-foreground))",
      boxShadow: "var(--shadow-md)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 8,
      borderBottom: "1px solid hsl(var(--border))"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      height: 32,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--background))",
      padding: "0 10px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Search",
    size: 14,
    color: "hsl(var(--muted-foreground))"
  }), /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Search restaurants & groups\u2026",
    "aria-label": "Search restaurants and groups",
    style: {
      flex: 1,
      minWidth: 0,
      background: "transparent",
      border: 0,
      outline: "none",
      font: "inherit",
      fontFamily: "var(--font-sans)",
      fontSize: 14
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: 288,
      overflow: "auto",
      padding: 4
    }
  }, shown.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 8px",
      textAlign: "center",
      fontSize: 12,
      color: "hsl(var(--muted-foreground))"
    }
  }, "No matches") : null, shown.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.label
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "6px 8px",
      fontSize: 10,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "hsl(var(--muted-foreground))"
    }
  }, g.label), g.items.map(it => /*#__PURE__*/React.createElement(StoreRow, {
    key: it,
    label: it,
    selected: store === it,
    onPick: () => pick(it)
  })))))) : null);
}
function StoreRow({
  label,
  selected,
  onPick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onPick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      width: "100%",
      alignItems: "center",
      gap: 4,
      borderRadius: "var(--radius-sm)",
      border: 0,
      padding: "6px 8px 6px 0",
      textAlign: "left",
      font: "inherit",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: selected ? 600 : 400,
      cursor: "pointer",
      background: hover ? "hsl(var(--accent))" : "transparent",
      color: hover ? "hsl(var(--accent-foreground))" : "inherit"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 24,
      display: "flex",
      justifyContent: "center",
      flexShrink: 0
    }
  }, selected ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Check",
    size: 16
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, label));
}
Object.assign(__ds_scope, { RISE_STORE_GROUPS, StorePicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/StorePicker.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Topbar.jsx
try { (() => {
function Topbar({
  user = "M",
  userPhoto,
  store,
  onStoreChange,
  placeholder = "Ask RISE anything…",
  style
}) {
  const [q, setQ] = React.useState("");
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 56,
      flexShrink: 0,
      borderBottom: "1px solid hsl(var(--border))",
      background: "hsl(var(--background))",
      display: "flex",
      alignItems: "center",
      gap: 14,
      padding: "0 16px",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StorePicker, {
    value: store,
    onChange: onStoreChange
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      maxWidth: 460,
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Search",
    size: 14,
    color: "hsl(var(--muted-foreground))",
    style: {
      position: "absolute",
      left: 12,
      top: "50%",
      transform: "translateY(-50%)"
    }
  }), /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: placeholder,
    "aria-label": "Ask RISE",
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      height: 36,
      width: "100%",
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--input))",
      background: focus ? "hsl(var(--background))" : "hsl(var(--muted) / .6)",
      padding: "0 48px 0 36px",
      font: "inherit",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      outline: "none",
      boxShadow: focus ? "0 0 0 1px hsl(var(--ring))" : "none",
      transition: "background var(--duration-fast) var(--ease-default)"
    }
  }), /*#__PURE__*/React.createElement("kbd", {
    style: {
      position: "absolute",
      right: 12,
      top: "50%",
      transform: "translateY(-50%)",
      borderRadius: 4,
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--background))",
      padding: "0 6px",
      fontSize: 10.5,
      fontFamily: "var(--font-sans)",
      color: "hsl(var(--muted-foreground))"
    }
  }, "\u2318K")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    initials: user,
    src: userPhoto
  })));
}
Object.assign(__ds_scope, { Topbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Topbar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Shell.jsx
try { (() => {
function Shell({
  active,
  onSelect,
  reports,
  categories,
  user = "M",
  store,
  onStoreChange,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      height: "100%",
      background: "hsl(var(--background))",
      fontFamily: "var(--font-sans)",
      color: "hsl(var(--foreground))",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Rail, {
    active: active,
    onSelect: onSelect,
    reports: reports,
    categories: categories
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Topbar, {
    user: user,
    store: store,
    onStoreChange: onStoreChange
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      overflow: "auto",
      background: "hsl(var(--muted))"
    }
  }, children)));
}
function PageContainer({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1180,
      margin: "0 auto",
      padding: "22px 30px 40px",
      display: "flex",
      flexDirection: "column",
      gap: 16,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Shell, PageContainer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Shell.jsx", error: String((e && e.message) || e) }); }

// components/overlays/AskModal.jsx
try { (() => {
const DEFAULT_SUGG = ["Why did this change vs. last week?", "Which restaurants drove it?", "What should I do about it?"];
function AskModal({
  open,
  onClose,
  title,
  sub,
  context,
  suggestions = DEFAULT_SUGG,
  answerFor
}) {
  const [turns, setTurns] = React.useState([]);
  const [q, setQ] = React.useState("");
  const [shown, setShown] = React.useState(false);
  const scroller = React.useRef(null);
  React.useEffect(() => {
    if (!open) {
      setShown(false);
      return;
    }
    const t = window.setTimeout(() => setShown(true), 10);
    const h = e => {
      if (e.key === "Escape") onClose && onClose();
    };
    window.addEventListener("keydown", h);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener("keydown", h);
    };
  }, [open, onClose]);
  React.useEffect(() => {
    if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [turns]);
  if (!open) return null;
  const send = text => {
    const question = (text != null ? text : q).trim();
    if (!question) return;
    const answer = answerFor ? answerFor(question) : "For " + title + ", I'd compare the weakest segment against your 12-week average and act on the biggest gap first.";
    setTurns(t => [...t, {
      r: "u",
      t: question
    }, {
      r: "typing"
    }]);
    setQ("");
    window.setTimeout(() => setTurns(t => t.map(m => m.r === "typing" ? {
      r: "a",
      t: answer
    } : m)), 750);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 50,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("style", null, "@keyframes rise-bounce{0%,100%{transform:translateY(-25%);animation-timing-function:cubic-bezier(.8,0,1,1)}50%{transform:none;animation-timing-function:cubic-bezier(0,0,.2,1)}}"), /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "absolute",
      inset: 0,
      background: "rgba(0,0,0,.6)",
      backdropFilter: "blur(4px)",
      opacity: shown ? 1 : 0,
      transition: "opacity var(--duration-overlay) var(--ease-default)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    "aria-label": "Ask RISE about " + title,
    style: {
      position: "relative",
      zIndex: 10,
      width: "100%",
      maxWidth: 512,
      maxHeight: "86vh",
      display: "flex",
      flexDirection: "column",
      borderRadius: "var(--radius-2xl)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--card))",
      overflow: "hidden",
      boxShadow: "var(--shadow-2xl)",
      opacity: shown ? 1 : 0,
      transform: shown ? "scale(1) translateY(0)" : "scale(.95) translateY(8px)",
      transition: "all var(--duration-overlay) var(--ease-default)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 16px",
      background: "var(--gradient-brand)",
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 36,
      width: 36,
      borderRadius: "var(--radius-xl)",
      background: "rgba(255,255,255,.15)",
      boxShadow: "inset 0 0 0 1px rgba(255,255,255,.25)",
      display: "grid",
      placeItems: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SparkMark, {
    size: 22
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 800,
      letterSpacing: "var(--tracking-tight)",
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, "Ask RISE", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 9,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-widest)",
      background: "rgba(255,255,255,.2)",
      borderRadius: 4,
      padding: "2px 6px"
    }
  }, "AI")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: "rgba(255,255,255,.8)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, title)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Close",
    style: {
      height: 28,
      width: 28,
      borderRadius: "var(--radius-full)",
      border: 0,
      background: "rgba(255,255,255,0)",
      display: "grid",
      placeItems: "center",
      cursor: "pointer",
      color: "rgba(255,255,255,.8)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "X",
    size: 16
  })))), /*#__PURE__*/React.createElement("div", {
    ref: scroller,
    style: {
      flex: 1,
      overflow: "auto",
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: "var(--radius-xl)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--muted) / .4)",
      padding: 12,
      fontSize: 13,
      boxShadow: "var(--shadow-sm)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      fontSize: 10,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "hsl(var(--primary))",
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Sparkles",
    size: 12
  }), "Context"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600
    }
  }, title, sub ? " — " + sub : ""), context ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: "hsl(var(--muted-foreground))",
      marginTop: 4,
      lineHeight: "var(--leading-relaxed)"
    }
  }, context) : null), turns.map((m, i) => m.r === "u" ? /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      justifyContent: "flex-end"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "80%",
      borderRadius: "var(--radius-2xl) var(--radius-2xl) var(--radius-md) var(--radius-2xl)",
      background: "hsl(var(--primary))",
      color: "hsl(var(--primary-foreground))",
      padding: "8px 14px",
      fontSize: 13,
      boxShadow: "var(--shadow-sm)"
    }
  }, m.t)) : /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      flexShrink: 0,
      display: "grid",
      placeItems: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SparkMark, {
    size: 28
  })), m.r === "typing" ? /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: "var(--radius-2xl) var(--radius-2xl) var(--radius-2xl) var(--radius-md)",
      background: "hsl(var(--muted))",
      padding: "12px 14px",
      display: "flex",
      alignItems: "center",
      gap: 4
    }
  }, [0, 1, 2].map(d => /*#__PURE__*/React.createElement("span", {
    key: d,
    style: {
      width: 6,
      height: 6,
      borderRadius: "var(--radius-full)",
      background: "hsl(var(--muted-foreground) / .6)",
      animation: "rise-bounce 1s infinite",
      animationDelay: d * 0.15 + "s"
    }
  }))) : /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "85%",
      borderRadius: "var(--radius-2xl) var(--radius-2xl) var(--radius-2xl) var(--radius-md)",
      background: "hsl(var(--muted))",
      padding: "8px 14px",
      fontSize: 13,
      lineHeight: "var(--leading-relaxed)",
      boxShadow: "var(--shadow-sm)"
    }
  }, m.t))), turns.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      color: "hsl(var(--muted-foreground))",
      marginBottom: 8,
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Sparkles",
    size: 12,
    color: "hsl(var(--primary))"
  }), "Suggested questions"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, suggestions.map(s => /*#__PURE__*/React.createElement(SuggestionChip, {
    key: s,
    label: s,
    onClick: () => send(s)
  })))) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid hsl(var(--border))",
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      borderRadius: "var(--radius-full)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--background))",
      paddingLeft: 8,
      paddingRight: 6,
      height: 44
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Attach a file",
    style: {
      height: 32,
      width: 32,
      borderRadius: "var(--radius-full)",
      border: 0,
      background: "none",
      display: "grid",
      placeItems: "center",
      cursor: "pointer",
      color: "hsl(var(--muted-foreground))",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Paperclip",
    size: 16
  })), /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    onKeyDown: e => {
      if (e.key === "Enter") send();
    },
    placeholder: "Ask anything about this chart\u2026",
    "aria-label": "Ask RISE",
    style: {
      flex: 1,
      minWidth: 0,
      background: "transparent",
      border: 0,
      outline: "none",
      font: "inherit",
      fontFamily: "var(--font-sans)",
      fontSize: 13
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => send(),
    disabled: !q.trim(),
    "aria-label": "Send",
    style: {
      height: 32,
      width: 32,
      borderRadius: "var(--radius-full)",
      border: 0,
      background: "hsl(var(--primary))",
      color: "hsl(var(--primary-foreground))",
      display: "grid",
      placeItems: "center",
      cursor: q.trim() ? "pointer" : "default",
      opacity: q.trim() ? 1 : 0.4,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "ArrowUp",
    size: 16
  }))))));
}
function SuggestionChip({
  label,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      textAlign: "left",
      borderRadius: "var(--radius-xl)",
      border: "1px solid " + (hover ? "hsl(var(--primary) / .5)" : "hsl(var(--border))"),
      background: hover ? "hsl(var(--primary) / .05)" : "hsl(var(--card))",
      padding: "10px 14px",
      font: "inherit",
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      cursor: "pointer",
      transition: "all var(--duration-fast) var(--ease-default)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, label), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "ArrowRight",
    size: 14,
    color: hover ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))"
  }));
}
Object.assign(__ds_scope, { AskModal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/AskModal.jsx", error: String((e && e.message) || e) }); }

// components/overlays/Dialog.jsx
try { (() => {
function Dialog({
  open,
  onClose,
  width = 512,
  children,
  style
}) {
  React.useEffect(() => {
    if (!open) return;
    const h = e => {
      if (e.key === "Escape") onClose && onClose();
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 50,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "absolute",
      inset: 0,
      background: "rgba(0,0,0,.5)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    style: {
      position: "relative",
      zIndex: 10,
      width: "100%",
      maxWidth: width,
      display: "grid",
      gap: 16,
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--background))",
      padding: 24,
      borderRadius: "var(--radius-xl)",
      boxShadow: "var(--shadow-lg)",
      ...style
    }
  }, children, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Close",
    style: {
      position: "absolute",
      right: 16,
      top: 16,
      border: 0,
      background: "none",
      padding: 4,
      borderRadius: "var(--radius-sm)",
      cursor: "pointer",
      opacity: 0.7,
      color: "inherit",
      lineHeight: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "X",
    size: 16
  }))));
}
function DialogHeader({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      paddingRight: 28,
      ...style
    }
  }, children);
}
function DialogTitle({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 18,
      fontWeight: 600,
      lineHeight: 1,
      letterSpacing: "var(--tracking-tight)",
      ...style
    }
  }, children);
}
function DialogDescription({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: "hsl(var(--muted-foreground))",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Dialog, DialogHeader, DialogTitle, DialogDescription });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/overlays/DropdownMenu.jsx
try { (() => {
function DropdownMenu({
  trigger,
  align = "start",
  width,
  children,
  style
}) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const h = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [open]);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => setOpen(o => !o),
    style: {
      display: "inline-flex"
    }
  }, trigger), open ? /*#__PURE__*/React.createElement("div", {
    role: "menu",
    onClick: () => setOpen(false),
    style: {
      position: "absolute",
      top: "calc(100% + 4px)",
      [align === "end" ? "right" : "left"]: 0,
      zIndex: 50,
      minWidth: width || 176,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--popover))",
      color: "hsl(var(--popover-foreground))",
      boxShadow: "var(--shadow-md)",
      padding: 4,
      overflow: "hidden"
    }
  }, children) : null);
}
function DropdownMenuItem({
  icon,
  checked,
  children,
  onClick,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "menuitem",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      width: "100%",
      alignItems: "center",
      gap: 8,
      borderRadius: "var(--radius-sm)",
      border: 0,
      padding: checked === undefined ? "6px 8px" : "6px 8px 6px 32px",
      position: "relative",
      textAlign: "left",
      font: "inherit",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      cursor: "pointer",
      background: hover ? "hsl(var(--accent))" : "transparent",
      color: hover ? "hsl(var(--accent-foreground))" : "inherit",
      ...style
    }
  }, checked !== undefined ? /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 8,
      display: "inline-flex"
    }
  }, checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Check",
    size: 16
  }) : null) : null, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    color: "hsl(var(--muted-foreground))"
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, children));
}
function DropdownMenuLabel({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "6px 8px",
      fontSize: 10,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "hsl(var(--muted-foreground))",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { DropdownMenu, DropdownMenuItem, DropdownMenuLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/DropdownMenu.jsx", error: String((e && e.message) || e) }); }

// components/overlays/Sheet.jsx
try { (() => {
function Sheet({
  open,
  onClose,
  width = 460,
  children,
  style
}) {
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    if (!open) {
      setShown(false);
      return;
    }
    const t = window.setTimeout(() => setShown(true), 10);
    const h = e => {
      if (e.key === "Escape") onClose && onClose();
    };
    window.addEventListener("keydown", h);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener("keydown", h);
    };
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 50
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "absolute",
      inset: 0,
      background: "rgba(0,0,0,.4)",
      opacity: shown ? 1 : 0,
      transition: "opacity var(--duration-overlay) var(--ease-default)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    style: {
      position: "absolute",
      right: 0,
      top: 0,
      height: "100%",
      width: "100%",
      maxWidth: width,
      background: "hsl(var(--background))",
      borderLeft: "1px solid hsl(var(--border))",
      boxShadow: "var(--shadow-2xl)",
      display: "flex",
      flexDirection: "column",
      transform: shown ? "translateX(0)" : "translateX(100%)",
      transition: "transform var(--duration-overlay) var(--ease-default)",
      ...style
    }
  }, children));
}
function SheetHeader({
  title,
  sub,
  actions,
  onClose,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 8,
      padding: "12px 16px",
      borderBottom: "1px solid hsl(var(--border))",
      flexShrink: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 800,
      letterSpacing: "var(--tracking-tight)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, title), sub ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: "hsl(var(--muted-foreground))",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, sub) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      flexShrink: 0
    }
  }, actions, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Close",
    style: {
      height: 28,
      width: 28,
      borderRadius: "var(--radius-full)",
      border: 0,
      background: "none",
      display: "grid",
      placeItems: "center",
      cursor: "pointer",
      color: "hsl(var(--muted-foreground))"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "X",
    size: 16
  }))));
}
function SheetBody({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto",
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      ...style
    }
  }, children);
}
function SheetFooter({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid hsl(var(--border))",
      background: "hsl(var(--muted) / .4)",
      padding: "12px 16px",
      flexShrink: 0,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Sheet, SheetHeader, SheetBody, SheetFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/Sheet.jsx", error: String((e && e.message) || e) }); }

// components/overlays/CommentSheet.jsx
try { (() => {
function CommentSheet({
  open,
  onClose,
  title,
  sub,
  takeaway,
  tone,
  chart,
  comments = [],
  onPost,
  team = [],
  currentUser = "M"
}) {
  const [draft, setDraft] = React.useState("");
  const warn = tone === "warn";
  const mention = (draft.match(/@(\w*)$/) || [null, null])[1];
  const sugg = mention != null ? team.filter(([h, n]) => (h + n).toLowerCase().includes(mention.toLowerCase())) : [];
  const post = () => {
    if (!draft.trim()) return;
    onPost && onPost(draft.trim());
    setDraft("");
  };
  const renderBody = txt => String(txt).split(/(@\w+)/).map((p, i) => p.charAt(0) === "@" ? /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      color: "hsl(var(--primary))",
      fontWeight: 600
    }
  }, p) : /*#__PURE__*/React.createElement("span", {
    key: i
  }, p));
  return /*#__PURE__*/React.createElement(__ds_scope.Sheet, {
    open: open,
    onClose: onClose,
    width: 460
  }, /*#__PURE__*/React.createElement(__ds_scope.SheetHeader, {
    title: title,
    sub: sub,
    onClose: onClose
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: "auto",
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, chart ? /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: "var(--radius-xl)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--card))",
      padding: 12
    }
  }, chart) : null, takeaway ? /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: "var(--radius-xl)",
      padding: 12,
      display: "flex",
      gap: 10,
      border: "1px solid " + (warn ? "hsl(var(--destructive) / .3)" : "hsl(var(--primary) / .2)"),
      background: warn ? "hsl(var(--destructive) / .05)" : "hsl(var(--accent))"
    }
  }, warn ? /*#__PURE__*/React.createElement("span", {
    style: {
      height: 32,
      width: 32,
      flexShrink: 0,
      borderRadius: "var(--radius-md)",
      background: "hsl(var(--destructive))",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "TriangleAlert",
    size: 16,
    color: "#fff"
  })) : /*#__PURE__*/React.createElement(__ds_scope.SparkMark, {
    size: 32
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700
    }
  }, "RISE"), /*#__PURE__*/React.createElement("span", {
    style: {
      borderRadius: 4,
      background: "hsl(var(--muted))",
      padding: "2px 6px",
      fontSize: 9,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "hsl(var(--muted-foreground))"
    }
  }, "Bot")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "hsl(var(--foreground) / .9)",
      marginTop: 4,
      lineHeight: "var(--leading-relaxed)"
    }
  }, takeaway))) : null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    style: {
      marginBottom: 8
    }
  }, comments.length > 0 ? comments.length + (comments.length === 1 ? " reply" : " replies") : "Comments"), comments.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "hsl(var(--muted-foreground))"
    }
  }, "No comments yet \u2014 start the thread.") : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, comments.map((c, i) => {
    const co = typeof c === "string" ? {
      body: c,
      author: "Maria",
      when: "just now",
      initials: currentUser
    } : c;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: "flex",
        gap: 8,
        fontSize: 13
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
      initials: co.initials || currentUser,
      size: 24,
      color: co.color
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "hsl(var(--muted) / .6)",
        borderRadius: "var(--radius-lg)",
        padding: "6px 10px",
        wordBreak: "break-word"
      }
    }, renderBody(co.body)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: "hsl(var(--muted-foreground))",
        marginTop: 2
      }
    }, co.author || "Maria", " \xB7 ", co.when || "just now")));
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid hsl(var(--border))",
      padding: 12,
      position: "relative"
    }
  }, sugg.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: "calc(100% + 4px)",
      left: 12,
      zIndex: 20,
      width: 224,
      borderRadius: "var(--radius-lg)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--popover))",
      boxShadow: "var(--shadow-md)",
      padding: 4
    }
  }, sugg.map(([handle, name]) => /*#__PURE__*/React.createElement("button", {
    key: handle,
    type: "button",
    onMouseDown: e => {
      e.preventDefault();
      setDraft(draft.replace(/@(\w*)$/, "@" + handle + " "));
    },
    style: {
      display: "flex",
      width: "100%",
      alignItems: "center",
      gap: 8,
      borderRadius: "var(--radius-sm)",
      border: 0,
      background: "none",
      padding: "6px 8px",
      font: "inherit",
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      textAlign: "left",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    initials: handle.charAt(0),
    size: 24,
    color: "hsl(var(--muted))",
    style: {
      color: "hsl(var(--foreground))"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "hsl(var(--muted-foreground))"
    }
  }, "@", handle)))) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    initials: currentUser,
    size: 28
  }), /*#__PURE__*/React.createElement("input", {
    value: draft,
    onChange: e => setDraft(e.target.value),
    onKeyDown: e => {
      if (e.key === "Enter" && sugg.length === 0) post();
    },
    placeholder: "Add a comment, @mention a teammate\u2026",
    "aria-label": "Add a comment",
    style: {
      height: 36,
      flex: 1,
      minWidth: 0,
      borderRadius: "var(--radius-md)",
      border: "1px solid hsl(var(--input))",
      background: "hsl(var(--background))",
      padding: "0 12px",
      font: "inherit",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      outline: "none"
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Attach a file",
    style: {
      height: 36,
      width: 36,
      borderRadius: "var(--radius-full)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--background))",
      color: "hsl(var(--muted-foreground))",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Paperclip",
    size: 16
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: post,
    "aria-label": "Post comment",
    style: {
      height: 36,
      width: 36,
      borderRadius: "var(--radius-full)",
      border: 0,
      background: "hsl(var(--primary))",
      color: "hsl(var(--primary-foreground))",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "Send",
    size: 16
  })))));
}
Object.assign(__ds_scope, { CommentSheet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/CommentSheet.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  style,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderRadius: "var(--radius-xl)",
      border: "1px solid hsl(var(--border))",
      background: "hsl(var(--card))",
      color: "hsl(var(--card-foreground))",
      boxShadow: "var(--shadow)",
      ...style
    }
  }, rest), children);
}
function CardContent({
  padding = 24,
  style,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      padding,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card, CardContent });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/InsightCard.jsx
try { (() => {
const RISE_ACTIONS = [["Ask RISE", "Sparkles"], ["Download CSV", "Download"], ["Comment", "MessageSquare"]];
function InsightCard({
  takeaway,
  tone,
  clamp = 2,
  replies = 0,
  onAsk,
  onDownload,
  onComment,
  onTakeawayClick,
  style
}) {
  const warn = tone === "warn";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      borderRadius: "var(--radius-xl)",
      overflow: "hidden",
      border: "1px solid " + (warn ? "hsl(var(--destructive) / .3)" : "hsl(var(--primary) / .2)"),
      background: warn ? "hsl(var(--destructive) / .05)" : "hsl(var(--accent))",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 12,
      display: "flex",
      gap: 10
    }
  }, warn ? /*#__PURE__*/React.createElement("span", {
    style: {
      height: 32,
      width: 32,
      flexShrink: 0,
      borderRadius: "var(--radius-md)",
      background: "hsl(var(--destructive))",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "TriangleAlert",
    size: 16,
    color: "#fff"
  })) : /*#__PURE__*/React.createElement(__ds_scope.SparkMark, {
    size: 32
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: "hsl(var(--foreground))"
    }
  }, "RISE"), /*#__PURE__*/React.createElement("span", {
    style: {
      borderRadius: 4,
      background: "hsl(var(--muted))",
      padding: "2px 6px",
      fontSize: 9,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "hsl(var(--muted-foreground))"
    }
  }, "Bot")), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onTakeawayClick,
    style: {
      width: "100%",
      textAlign: "left",
      border: 0,
      background: "none",
      padding: 0,
      marginTop: 4,
      font: "inherit",
      fontSize: 13,
      lineHeight: "var(--leading-relaxed)",
      color: "hsl(var(--foreground) / .9)",
      cursor: onTakeawayClick ? "pointer" : "default",
      display: "-webkit-box",
      WebkitLineClamp: clamp,
      WebkitBoxOrient: "vertical",
      overflow: "hidden"
    }
  }, takeaway))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 2,
      padding: "8px 8px",
      borderTop: "1px solid rgba(0,0,0,.05)"
    }
  }, RISE_ACTIONS.map(([label, icon]) => {
    const fn = label === "Ask RISE" ? onAsk : label === "Download CSV" ? onDownload : onComment;
    return /*#__PURE__*/React.createElement(InsightAction, {
      key: label,
      label: label,
      icon: icon,
      count: label === "Comment" ? replies : 0,
      onClick: fn
    });
  })));
}
function InsightAction({
  label,
  icon,
  count,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    title: label,
    "aria-label": label,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      height: 28,
      padding: "0 6px",
      borderRadius: "var(--radius-md)",
      border: 0,
      cursor: "pointer",
      font: "inherit",
      background: hover ? "hsl(var(--background) / .7)" : "transparent",
      color: hover ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground))",
      transition: "all var(--duration-fast) var(--ease-default)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16
  }), count > 0 ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 600
    }
  }, count) : null);
}
Object.assign(__ds_scope, { InsightCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/InsightCard.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/NextRightThing.jsx
try { (() => {
function NextRightThing({
  eyebrow = "The next right thing",
  impact,
  action,
  reason,
  cta,
  onCta,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: "var(--radius-xl)",
      background: "hsl(var(--primary))",
      color: "hsl(var(--primary-foreground))",
      boxShadow: "var(--shadow)",
      padding: 20,
      display: "flex",
      alignItems: "center",
      gap: 20,
      flexWrap: "wrap",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SparkMark, {
    size: 48,
    invert: true,
    style: {
      borderRadius: 12
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 240
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-widest)",
      color: "hsl(var(--primary-foreground) / .85)"
    }
  }, eyebrow), impact ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    variant: "yellow"
  }, impact) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 800,
      letterSpacing: "var(--tracking-tight)",
      marginTop: 4,
      lineHeight: "var(--leading-tight)",
      textWrap: "balance"
    }
  }, action), reason ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: "hsl(var(--primary-foreground) / .9)",
      marginTop: 8,
      marginBottom: 0,
      maxWidth: 640,
      lineHeight: "var(--leading-relaxed)"
    }
  }, reason) : null), cta ? /*#__PURE__*/React.createElement(__ds_scope.Button, {
    onClick: onCta,
    style: {
      background: "hsl(var(--background))",
      color: "hsl(var(--primary))",
      fontWeight: 700
    }
  }, cta) : null);
}
Object.assign(__ds_scope, { NextRightThing });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/NextRightThing.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/PageHead.jsx
try { (() => {
function PageHead({
  eyebrow,
  title,
  blurb,
  tag,
  action,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 12,
      flexWrap: "wrap",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", null, eyebrow ? /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, eyebrow) : null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 26,
      fontWeight: 800,
      letterSpacing: "var(--tracking-tight)",
      color: "hsl(var(--foreground))"
    }
  }, title), blurb ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: "hsl(var(--muted-foreground))",
      marginTop: 4,
      marginBottom: 0,
      maxWidth: 600
    }
  }, blurb) : null, tag ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, tag) : null), action ? /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0
    }
  }, action) : null);
}
Object.assign(__ds_scope, { PageHead });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/PageHead.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Panel.jsx
try { (() => {
function Panel({
  title,
  sub,
  takeaway,
  tone,
  replies,
  onAsk,
  onDownload,
  onComment,
  onTakeawayClick,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    style: {
      position: "relative",
      height: "100%",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.CardContent, {
    padding: 18,
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 14,
      fontWeight: 800,
      letterSpacing: "var(--tracking-tight)",
      color: "hsl(var(--foreground))"
    }
  }, title), sub ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "hsl(var(--muted-foreground))",
      marginTop: 2
    }
  }, sub) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, children), takeaway ? /*#__PURE__*/React.createElement(__ds_scope.InsightCard, {
    takeaway: takeaway,
    tone: tone,
    replies: replies,
    onAsk: onAsk,
    onDownload: onDownload,
    onComment: onComment,
    onTakeawayClick: onTakeawayClick
  }) : null));
}
Object.assign(__ds_scope, { Panel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Panel.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/ScaffoldFrame.jsx
try { (() => {
function ScaffoldFrame({
  label,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: "var(--radius-lg)",
      border: "1px dashed hsl(var(--border))",
      background: "hsl(var(--muted) / .4)",
      height: 188,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      color: "hsl(var(--muted-foreground) / .6)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "LineChart",
    size: 24
  }), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600
    }
  }, label) : null);
}
Object.assign(__ds_scope, { ScaffoldFrame });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/ScaffoldFrame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rise-home/HomeScreen.jsx
try { (() => {
// RISE Home — hero, key metrics + benchmark, and the To Do list with drill-in sheets.
(function () {
  const DS = window.RISEDesignSystem_6a845d;
  const {
    Shell,
    PageContainer,
    Card,
    CardContent,
    NextRightThing,
    Kpi,
    RankCard,
    Delta,
    Tabs,
    Select,
    CustomDateButton,
    MultiFilterChip,
    GroupByChip,
    TaskRow,
    Avatar,
    Badge,
    Button,
    Checkbox,
    Eyebrow,
    Icon,
    InsightCard,
    Sheet,
    SheetHeader,
    SheetBody,
    SheetFooter,
    DropdownMenu,
    DropdownMenuItem,
    DropdownMenuLabel
  } = DS;
  const D = window.RISE_HOME;
  const clean = s => String(s).replace(/[▲▼]/g, "").trim();

  /* ── panel chrome shared by both drill-in sheets ── */
  const PanelActions = () => /*#__PURE__*/React.createElement(DropdownMenu, {
    align: "end",
    trigger: /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      size: "icon",
      style: {
        width: 28,
        height: 28,
        borderRadius: "var(--radius-full)"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "MoreHorizontal",
      size: 16
    }))
  }, /*#__PURE__*/React.createElement(DropdownMenuItem, {
    icon: "Plus"
  }, "Add to dashboard"), /*#__PURE__*/React.createElement(DropdownMenuItem, {
    icon: "Download"
  }, "Download"), /*#__PURE__*/React.createElement(DropdownMenuItem, {
    icon: "Share2"
  }, "Share"), /*#__PURE__*/React.createElement(DropdownMenuItem, {
    icon: "MessageSquare"
  }, "Comment"));
  const MiniBars = ({
    bars,
    label,
    tone = "primary"
  }) => {
    const max = Math.max.apply(null, bars);
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
      style: {
        marginBottom: 6
      }
    }, label), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-end",
        gap: 4,
        height: 88,
        borderBottom: "1px solid hsl(var(--border))"
      }
    }, bars.map((b, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        flex: 1,
        borderRadius: "4px 4px 0 0",
        height: b / max * 100 + "%",
        background: tone === "primary" ? "hsl(var(--primary))" : "hsl(var(--destructive))",
        opacity: i === bars.length - 1 ? 1 : 0.5
      }
    }))));
  };
  const StatGrid = ({
    stats,
    columns = 2
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(" + columns + ",1fr)",
      gap: 10
    }
  }, stats.map(([l, v]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      borderRadius: "var(--radius-lg)",
      border: "1px solid hsl(var(--border))",
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      color: "hsl(var(--muted-foreground))"
    }
  }, l), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 800,
      letterSpacing: "var(--tracking-tight)",
      marginTop: 2
    }
  }, v))));
  const DetailRows = ({
    rows
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: "var(--radius-lg)",
      border: "1px solid hsl(var(--border))",
      overflow: "hidden"
    }
  }, rows.map(([k, v], i) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "8px 12px",
      fontSize: 14,
      borderTop: i ? "1px solid hsl(var(--border))" : 0
    }
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums"
    }
  }, v))));

  /* ── KPI drill-in ── */
  function KpiSheet({
    kpi,
    range,
    onClose
  }) {
    if (!kpi) return null;
    const data = kpi[range] || kpi.today;
    const bars = [60, 64, 70, 68, 74, 80, 86, 82, 88];
    const rangeLabel = (D.ranges.find(([k]) => k === range) || ["", "Custom"])[1];
    return /*#__PURE__*/React.createElement(Sheet, {
      open: !!kpi,
      onClose: onClose,
      width: 480
    }, /*#__PURE__*/React.createElement(SheetHeader, {
      title: kpi.k,
      sub: "Metric · " + rangeLabel,
      onClose: onClose,
      actions: /*#__PURE__*/React.createElement(PanelActions, null)
    }), /*#__PURE__*/React.createElement(SheetBody, null, /*#__PURE__*/React.createElement(InsightCard, {
      style: {
        marginTop: 0
      },
      clamp: 0,
      takeaway: kpi.action + " — " + data.why
    }), /*#__PURE__*/React.createElement(Eyebrow, null, "Here's what we're seeing"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        marginTop: -8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 36,
        fontWeight: 800,
        letterSpacing: "var(--tracking-tight)",
        fontVariantNumeric: "tabular-nums"
      }
    }, data.v), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        fontWeight: 700,
        color: kpi.good === false ? "hsl(var(--destructive))" : "hsl(var(--primary))"
      }
    }, clean(data.d), " ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "hsl(var(--muted-foreground))",
        fontWeight: 400
      }
    }, "vs target ", data.target)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "hsl(var(--muted-foreground))",
        marginTop: 2
      }
    }, data.headline, "."))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10
      }
    }, [["vs region", data.region], ["vs system", data.system]].map(([lbl, v]) => /*#__PURE__*/React.createElement("div", {
      key: lbl,
      style: {
        flex: 1,
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--border))",
        background: "hsl(var(--muted) / .4)",
        padding: "8px 12px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        fontWeight: 700,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        color: "hsl(var(--muted-foreground))"
      }
    }, lbl), /*#__PURE__*/React.createElement(Delta, {
      value: v,
      dir: kpi.dir,
      good: kpi.good,
      size: "lg",
      style: {
        marginTop: 2
      }
    })))), /*#__PURE__*/React.createElement(MiniBars, {
      bars: bars,
      label: "How " + kpi.k.toLowerCase() + " is tracking · " + rangeLabel.toLowerCase(),
      tone: kpi.good === false ? "destructive" : "primary"
    }), data.breakdown ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
      style: {
        marginBottom: 6
      }
    }, "Where it's coming from"), /*#__PURE__*/React.createElement(DetailRows, {
      rows: data.breakdown
    })) : null), /*#__PURE__*/React.createElement(SheetFooter, null, /*#__PURE__*/React.createElement(Button, {
      style: {
        width: "100%"
      }
    }, kpi.action)));
  }

  /* ── Task drill-in ── */
  function TaskSheet({
    task,
    onClose
  }) {
    if (!task) return null;
    const O = D.tomatoOrder;
    const cases = O.allocation.reduce((s, a) => s + a.cases, 0);
    const total = cases * O.unitCost;
    const money = n => "$" + n.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    const type = D.taskTypes[task.type];
    return /*#__PURE__*/React.createElement(Sheet, {
      open: !!task,
      onClose: onClose,
      width: 520
    }, /*#__PURE__*/React.createElement(SheetHeader, {
      title: task.t,
      sub: task.w + " · " + task.store,
      onClose: onClose,
      actions: /*#__PURE__*/React.createElement(PanelActions, null)
    }), /*#__PURE__*/React.createElement(SheetBody, null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        borderRadius: "var(--radius-full)",
        border: "1px solid hsl(var(--primary))",
        color: "hsl(var(--primary))",
        padding: "2px 8px",
        fontSize: 10,
        fontWeight: 700
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 6,
        height: 6,
        borderRadius: "var(--radius-full)",
        background: "hsl(var(--primary))"
      }
    }), type && type.label), /*#__PURE__*/React.createElement(Badge, {
      variant: task.hot ? "destructive" : "secondary",
      style: {
        fontSize: 10
      }
    }, task.due)), task.order ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(InsightCard, {
      style: {
        marginTop: 0
      },
      clamp: 0,
      takeaway: "Place a " + cases + "-case tomato order with " + O.vendor + " before today's 4 PM cutoff. Based on the 4-week sales average plus Thu lunch forecast (+12%), confidence " + O.confidence + "%. Without this order, 5 of 7 restaurants stock out by Thu lunch."
    }), /*#__PURE__*/React.createElement(Eyebrow, null, "Supporting evidence"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--border))",
        padding: 12
      }
    }, /*#__PURE__*/React.createElement(Eyebrow, {
      style: {
        fontSize: 10
      }
    }, "Vendor"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        fontWeight: 600,
        marginTop: 4
      }
    }, O.vendor), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "hsl(var(--muted-foreground))",
        marginTop: 2
      }
    }, money(O.unitCost), " / ", O.unit)), /*#__PURE__*/React.createElement("div", {
      style: {
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--border))",
        padding: 12
      }
    }, /*#__PURE__*/React.createElement(Eyebrow, {
      style: {
        fontSize: 10
      }
    }, "Cutoff"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        fontWeight: 600,
        marginTop: 4,
        color: "hsl(var(--destructive))"
      }
    }, O.cutoff), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "hsl(var(--muted-foreground))",
        marginTop: 2
      }
    }, "Delivery ", O.delivery))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 6
      }
    }, /*#__PURE__*/React.createElement(Eyebrow, null, "Allocation by restaurant"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm",
      style: {
        height: 24,
        padding: "0 8px",
        fontSize: 11
      }
    }, "Edit qty")), /*#__PURE__*/React.createElement("div", {
      style: {
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--border))",
        overflow: "hidden"
      }
    }, O.allocation.map((a, i) => /*#__PURE__*/React.createElement("div", {
      key: a.store,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "8px 12px",
        borderTop: i ? "1px solid hsl(var(--border))" : 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 500
      }
    }, a.store), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "hsl(var(--muted-foreground))"
      }
    }, "on hand: ", a.current, " \xB7 ", a.cover)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        borderRadius: "var(--radius-full)",
        border: "1px solid hsl(var(--border))",
        padding: "0 4px",
        fontSize: 12,
        fontWeight: 700
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 20,
        textAlign: "center",
        color: "hsl(var(--muted-foreground))"
      }
    }, "\u2212"), /*#__PURE__*/React.createElement("span", {
      style: {
        width: 24,
        textAlign: "center"
      }
    }, a.cases), /*#__PURE__*/React.createElement("span", {
      style: {
        width: 20,
        textAlign: "center",
        color: "hsl(var(--muted-foreground))"
      }
    }, "+")))))), /*#__PURE__*/React.createElement("div", {
      style: {
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--border))",
        background: "hsl(var(--muted) / .4)",
        padding: "12px 14px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between"
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "hsl(var(--muted-foreground))"
      }
    }, cases, " cases \xB7 7 restaurants"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        fontWeight: 500,
        color: "hsl(var(--muted-foreground) / .7)",
        marginTop: 2
      }
    }, "Charged to franchisee account \xB7 invoice on delivery")), /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "right"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 22,
        fontWeight: 800,
        letterSpacing: "var(--tracking-tight)",
        fontVariantNumeric: "tabular-nums"
      }
    }, money(total)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: "hsl(var(--muted-foreground))"
      }
    }, "order total")))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(InsightCard, {
      style: {
        marginTop: 0
      },
      clamp: 0,
      takeaway: task.a + " — " + task.t.toLowerCase() + ". " + task.w + "."
    }), /*#__PURE__*/React.createElement(Eyebrow, null, "Supporting evidence"), /*#__PURE__*/React.createElement(StatGrid, {
      stats: task.stats
    }), /*#__PURE__*/React.createElement(MiniBars, {
      bars: task.bars,
      label: task.barLabel
    }))), /*#__PURE__*/React.createElement(SheetFooter, null, /*#__PURE__*/React.createElement(Button, {
      style: {
        width: "100%"
      }
    }, task.order ? "Confirm order · " + money(total) : task.a)));
  }

  /* ── Key metrics block ── */
  function KeyMetrics({
    onOpenKpi
  }) {
    const [range, setRange] = React.useState("today");
    const [compareTo, setCompareTo] = React.useState("self");
    const rank = D.rank[range] || D.rank.today;
    const deltaFor = kpi => {
      const d = kpi[range] || kpi.today;
      return compareTo === "self" ? d.d : compareTo === "region" ? d.region : d.system;
    };
    return /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardContent, {
      padding: 18,
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "baseline",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        fontSize: 16,
        fontWeight: 800,
        letterSpacing: "var(--tracking-tight)"
      }
    }, "Key metrics"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "hsl(var(--muted-foreground))"
      }
    }, "click a tile to drill in")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Eyebrow, {
      style: {
        fontSize: 10
      }
    }, "Compare to"), /*#__PURE__*/React.createElement(Select, {
      value: compareTo,
      onChange: setCompareTo,
      options: D.compare,
      size: "sm"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Tabs, {
      value: range,
      onChange: setRange,
      size: "sm",
      items: D.ranges
    }), /*#__PURE__*/React.createElement(CustomDateButton, {
      active: range === "custom",
      onPick: () => setRange("custom")
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        alignItems: "stretch"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4,1fr)",
        gridAutoRows: "1fr",
        gap: 10,
        flex: 1,
        minWidth: 0
      }
    }, D.kpis.map(kpi => /*#__PURE__*/React.createElement(Kpi, {
      key: kpi.id,
      label: kpi.k,
      value: (kpi[range] || kpi.today).v,
      dir: kpi.dir,
      good: kpi.good,
      mag: deltaFor(kpi),
      onClick: () => onOpenKpi(kpi, range)
    }))), /*#__PURE__*/React.createElement(RankCard, {
      percentile: rank.pct,
      move: rank.move,
      scopeNote: "average of your 14 restaurants",
      ranks: rank.ranks
    }))));
  }

  /* ── To Do ── */
  function ToDo({
    onOpenTask
  }) {
    const [scope, setScope] = React.useState("all");
    const [typeF, setTypeF] = React.useState([]);
    const [restF, setRestF] = React.useState([]);
    const [groupBy, setGroupBy] = React.useState("type");
    const [sel, setSel] = React.useState([]);
    const [owner, setOwner] = React.useState({});
    const ownerOf = t => owner[t.id] || t.who;
    const stores = D.tasks.map(t => t.store).filter((s, i, a) => a.indexOf(s) === i);
    const filtered = D.tasks.filter(t => (scope === "all" || ownerOf(t) === "M") && (typeF.length === 0 || typeF.indexOf(t.type) > -1) && (restF.length === 0 || restF.indexOf(t.store) > -1));
    let groups;
    if (groupBy === "none") groups = [["", filtered]];else if (groupBy === "restaurant") groups = stores.map(s => [s, filtered.filter(t => t.store === s)]).filter(g => g[1].length);else if (groupBy === "urgency") groups = [["Urgent", filtered.filter(t => t.hot)], ["Later", filtered.filter(t => !t.hot)]].filter(g => g[1].length);else groups = ["schedule", "inventory", "menu"].map(k => [k, filtered.filter(t => t.type === k)]).filter(g => g[1].length);
    const bulk = sel.length > 0;
    const toggleSel = id => setSel(s => s.indexOf(id) > -1 ? s.filter(x => x !== id) : s.concat(id));
    const seg = [["all", "All", D.tasks.length], ["mine", "Mine", D.tasks.filter(t => ownerOf(t) === "M").length]];
    return /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardContent, {
      padding: 18,
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "baseline",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        fontSize: 16,
        fontWeight: 800,
        letterSpacing: "var(--tracking-tight)"
      }
    }, "To Do"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "hsl(var(--muted-foreground))"
      }
    }, filtered.length, " of ", D.tasks.length)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--border))",
        background: "hsl(var(--muted))",
        padding: 2,
        gap: 2
      }
    }, seg.map(([v, label, count]) => {
      const on = scope === v;
      return /*#__PURE__*/React.createElement("button", {
        key: v,
        type: "button",
        onMouseDown: e => e.preventDefault(),
        onClick: () => setScope(v),
        style: {
          display: "inline-flex",
          alignItems: "center",
          gap: 6,
          borderRadius: "var(--radius-md)",
          padding: "0 12px",
          height: 28,
          border: 0,
          fontFamily: "var(--font-sans)",
          fontSize: 12,
          fontWeight: 600,
          cursor: "pointer",
          background: on ? "hsl(var(--background))" : "transparent",
          color: on ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground))",
          boxShadow: on ? "var(--shadow)" : "none"
        }
      }, v === "mine" ? /*#__PURE__*/React.createElement(Avatar, {
        initials: "M",
        size: 16,
        style: {
          fontSize: 8
        }
      }) : null, label, /*#__PURE__*/React.createElement("span", {
        style: {
          color: "hsl(var(--muted-foreground))",
          fontWeight: 500
        }
      }, count));
    })), /*#__PURE__*/React.createElement(MultiFilterChip, {
      size: "sm",
      label: "Type",
      icon: "ListFilter",
      selected: typeF,
      onChange: setTypeF,
      options: Object.keys(D.taskTypes).map(k => [k, D.taskTypes[k].label])
    }), /*#__PURE__*/React.createElement(MultiFilterChip, {
      size: "sm",
      label: "Restaurant",
      icon: "MapPin",
      selected: restF,
      onChange: setRestF,
      options: stores.map(s => [s, s])
    })), /*#__PURE__*/React.createElement(GroupByChip, {
      value: groupBy,
      onChange: setGroupBy,
      options: [["type", "Type"], ["urgency", "Urgency"], ["restaurant", "Restaurant"], ["none", "None"]]
    })), bulk ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        borderRadius: "var(--radius-lg)",
        background: "hsl(var(--foreground))",
        color: "hsl(var(--background))",
        padding: "8px 12px"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        fontWeight: 600
      }
    }, sel.length, " selected"), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }), /*#__PURE__*/React.createElement(DropdownMenu, {
      align: "end",
      trigger: /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        variant: "ghost",
        style: {
          height: 28,
          color: "hsl(var(--background))"
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "UserPlus",
        size: 14
      }), "Re-assign")
    }, /*#__PURE__*/React.createElement(DropdownMenuLabel, null, "Assign to"), Object.keys(D.people).map(k => /*#__PURE__*/React.createElement(DropdownMenuItem, {
      key: k,
      onClick: () => {
        setOwner(o => {
          const m = Object.assign({}, o);
          sel.forEach(id => {
            m[id] = k;
          });
          return m;
        });
        setSel([]);
      }
    }, D.people[k].name))), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => setSel([]),
      style: {
        height: 28,
        background: "hsl(var(--background))",
        color: "hsl(var(--foreground))"
      }
    }, "Mark done"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      onClick: () => setSel([]),
      style: {
        height: 28,
        color: "hsl(var(--background))"
      }
    }, "Clear")) : null, filtered.length === 0 ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        padding: "48px 0",
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 40,
        height: 40,
        borderRadius: "var(--radius-full)",
        background: "hsl(var(--muted))",
        display: "grid",
        placeItems: "center"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "SearchX",
      size: 20,
      color: "hsl(var(--muted-foreground))"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        fontWeight: 600
      }
    }, "No to-dos match your filters"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "hsl(var(--muted-foreground))"
      }
    }, "Try clearing a filter or switching to All.")) : /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column"
      }
    }, groups.map(([g, list]) => /*#__PURE__*/React.createElement(React.Fragment, {
      key: g || "all"
    }, g ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        padding: "12px 4px 6px"
      }
    }, groupBy === "type" && D.taskTypes[g] ? /*#__PURE__*/React.createElement(Icon, {
      name: D.taskTypes[g].icon,
      size: 14,
      color: "hsl(var(--muted-foreground))"
    }) : null, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10.5,
        fontWeight: 700,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        color: "hsl(var(--muted-foreground))"
      }
    }, groupBy === "type" && D.taskTypes[g] ? D.taskTypes[g].label : g), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10.5,
        fontWeight: 600,
        color: "hsl(var(--muted-foreground) / .7)"
      }
    }, list.length)) : null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 8
      }
    }, list.map(t => {
      const who = D.people[ownerOf(t)];
      return /*#__PURE__*/React.createElement(TaskRow, {
        key: t.id,
        title: t.t,
        context: t.w + " · " + t.store,
        due: t.due,
        hot: t.hot,
        action: t.a,
        assignee: ownerOf(t),
        assigneePhoto: who && who.photo,
        assigneeColor: who && who.color,
        selected: sel.indexOf(t.id) > -1,
        bulkMode: bulk,
        onToggleSelect: () => toggleSel(t.id),
        onOpen: () => onOpenTask(t)
      });
    })))))));
  }
  function HomeScreen() {
    const [kpi, setKpi] = React.useState(null);
    const [kpiRange, setKpiRange] = React.useState("today");
    const [task, setTask] = React.useState(null);
    return /*#__PURE__*/React.createElement(Shell, {
      active: "home"
    }, /*#__PURE__*/React.createElement(PageContainer, null, /*#__PURE__*/React.createElement(NextRightThing, {
      impact: D.nrt.impact,
      action: D.nrt.action,
      reason: D.nrt.reason,
      cta: D.nrt.cta
    }), /*#__PURE__*/React.createElement(KeyMetrics, {
      onOpenKpi: (k, r) => {
        setKpi(k);
        setKpiRange(r);
      }
    }), /*#__PURE__*/React.createElement(ToDo, {
      onOpenTask: setTask
    })), /*#__PURE__*/React.createElement(KpiSheet, {
      kpi: kpi,
      range: kpiRange,
      onClose: () => setKpi(null)
    }), /*#__PURE__*/React.createElement(TaskSheet, {
      task: task,
      onClose: () => setTask(null)
    }));
  }
  window.RiseHomeScreen = HomeScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rise-home/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rise-home/data.js
try { (() => {
// Fixtures for the RISE Home kit — lifted from the prototype's rise-shadcn-home.jsx.
window.RISE_HOME = {
  user: {
    initials: "M",
    name: "Maria"
  },
  nrt: {
    action: "Work on drink upselling with your teams",
    impact: "~$1.7k/day upside",
    reason: "Restaurants like yours in the CT region are adding about 30 more drinks a day. Across your 14 locations that's roughly $1.7k/day left on the table — the fastest check-builder you have right now.",
    cta: "Nudge team"
  },
  ranges: [["today", "Today"], ["week", "Week"], ["month", "Month"], ["ytd", "YTD"]],
  compare: [["self", "Myself"], ["region", "Region"], ["system", "System"]],
  rank: {
    today: {
      pct: 88,
      move: "+2 this week",
      ranks: [["CT region", 2, 9], ["Subway system", 38, 312]]
    },
    week: {
      pct: 86,
      move: "+3 this week",
      ranks: [["CT region", 2, 9], ["Subway system", 44, 312]]
    },
    month: {
      pct: 84,
      move: "+5 this month",
      ranks: [["CT region", 2, 9], ["Subway system", 49, 312]]
    },
    ytd: {
      pct: 82,
      move: "+11 YTD",
      ranks: [["CT region", 3, 9], ["Subway system", 58, 312]]
    }
  },
  kpis: [{
    id: 0,
    k: "Sales",
    dir: "up",
    action: "Open sales report",
    today: {
      v: "$8,412",
      d: "+12%",
      region: "+6%",
      system: "+9%",
      target: "$7,480",
      headline: "Pacing $932 above plan",
      why: "Lunch run-rate is +18% vs last Tue, driven by #4421 and #552. Forecast stays busy through 2pm.",
      breakdown: [["#4421 Hartford", "+22%"], ["#552 Bridgeport", "+15%"], ["#1208 Stamford", "−4%"]]
    },
    week: {
      v: "$58.3k",
      d: "+8%",
      region: "+5%",
      system: "+8%",
      target: "$54.1k",
      headline: "On pace for a strong week",
      why: "Tue and Wed both beat forecast; Sat is the swing day."
    },
    month: {
      v: "$244k",
      d: "+6%",
      region: "+4%",
      system: "+7%",
      target: "$230k",
      headline: "On track for May target",
      why: "Catering pre-orders tracking strong."
    },
    ytd: {
      v: "$1.21M",
      d: "+5%",
      region: "+3%",
      system: "+6%",
      target: "$1.18M",
      headline: "Ahead of plan YTD",
      why: "Strong Q2 driven by LTOs and catering."
    }
  }, {
    id: 1,
    k: "Traffic",
    dir: "up",
    action: "View traffic mix",
    today: {
      v: "412",
      d: "+38",
      region: "+4%",
      system: "+7%",
      target: "374",
      headline: "+10% vs forecast",
      why: "Catering pre-orders at #4421 and #552 added 28 transactions so far today.",
      breakdown: [["Catering", "+28"], ["Digital", "+9"], ["Walk-in", "+1"]]
    },
    week: {
      v: "2,847",
      d: "+184",
      region: "+3%",
      system: "+6%",
      target: "2,663",
      headline: "+7% vs forecast",
      why: "Promo + weather helped weekday counts."
    },
    month: {
      v: "12.1k",
      d: "+0.5k",
      region: "+3%",
      system: "+5%",
      target: "11.6k",
      headline: "+4% vs forecast",
      why: "Steady growth in catering and digital."
    },
    ytd: {
      v: "62.4k",
      d: "+1.9k",
      region: "+2%",
      system: "+4%",
      target: "60.5k",
      headline: "+3% vs forecast YTD",
      why: "Catering is the clearest YoY growth driver."
    }
  }, {
    id: 2,
    k: "Avg check",
    dir: "up",
    action: "See check breakdown",
    today: {
      v: "$8.40",
      d: "+$0.20",
      region: "+$0.15",
      system: "+$0.30",
      target: "$8.30",
      headline: "Above target",
      why: "Footlong mix is up 3 pts vs avg. Cookies attaching better this morning.",
      breakdown: [["Breakfast", "$7.80"], ["Lunch", "$8.65"], ["Dinner", "$8.10"]]
    },
    week: {
      v: "$8.35",
      d: "+$0.10",
      region: "+$0.12",
      system: "+$0.28",
      target: "$8.30",
      headline: "Above target",
      why: "Holding steady. Footlong attach is the lever."
    },
    month: {
      v: "$8.30",
      d: "on target",
      region: "+$0.10",
      system: "+$0.25",
      target: "$8.30",
      headline: "Right on target",
      why: "Steady through May."
    },
    ytd: {
      v: "$8.25",
      d: "−$0.05",
      region: "+$0.05",
      system: "+$0.20",
      target: "$8.30",
      headline: "Just under target",
      why: "Q1 promo discounting pulled check down; recovering since April."
    }
  }, {
    id: 3,
    k: "Digital sales %",
    dir: "up",
    action: "See digital channel mix",
    today: {
      v: "34%",
      d: "+3",
      region: "+2%",
      system: "+5%",
      target: "31%",
      headline: "App + web mix climbing",
      why: "App orders up sharply at lunch — the new in-app combo deal is converting.",
      breakdown: [["App", "22%"], ["Web", "9%"], ["Kiosk", "3%"]]
    },
    week: {
      v: "33%",
      d: "+2",
      region: "+2%",
      system: "+4%",
      target: "31%",
      headline: "Above target",
      why: "Steady gains led by app reorders."
    },
    month: {
      v: "32%",
      d: "+1",
      region: "+1%",
      system: "+4%",
      target: "31%",
      headline: "Just above target",
      why: "Digital mix trending up as loyalty grows."
    },
    ytd: {
      v: "31%",
      d: "+4",
      region: "+2%",
      system: "+3%",
      target: "29%",
      headline: "Ahead of plan YTD",
      why: "YoY digital growth from app adoption + catering."
    }
  }, {
    id: 4,
    k: "Attachment rate",
    dir: "up",
    action: "Send coaching card to #732",
    today: {
      v: "1.6",
      d: "+0.1",
      region: "+0.1",
      system: "+0.2",
      target: "1.5",
      headline: "Above target",
      why: "AM crews recommending double-protein well — but #732 is still −9%. A coaching card could close the gap.",
      breakdown: [["#4421", "1.8"], ["#552", "1.7"], ["#732", "1.3"]]
    },
    week: {
      v: "1.55",
      d: "+0.05",
      region: "+0.08",
      system: "+0.18",
      target: "1.5",
      headline: "Above target",
      why: "Consistent across the week. Coaching at #732 pending."
    },
    month: {
      v: "1.52",
      d: "+0.02",
      region: "+0.05",
      system: "+0.15",
      target: "1.5",
      headline: "Just above target",
      why: "Improvement vs last month."
    },
    ytd: {
      v: "1.48",
      d: "−0.02",
      region: "+0.02",
      system: "+0.12",
      target: "1.5",
      headline: "Just under target YTD",
      why: "Q1 ran low; trending back up since April."
    }
  }, {
    id: 6,
    k: "Labor %",
    dir: "down",
    good: false,
    action: "Send closer home at #1208",
    today: {
      v: "26.4%",
      d: "+1.8",
      region: "−0.3",
      system: "−0.8",
      target: "24.6%",
      headline: "$340 over plan today",
      why: "Two restaurants are over: #1208 (+18%) and #4421 (+8%). Sending one closer home at #1208 saves ~$48 today without hurting SOS.",
      breakdown: [["#1208 Stamford", "+18% over"], ["#4421 Hartford", "+8% over"], ["#732 New Haven", "on target"]]
    },
    week: {
      v: "25.8%",
      d: "+1.2",
      region: "−0.4",
      system: "−0.9",
      target: "24.6%",
      headline: "$1.4k over plan this week",
      why: "Sat lunch over-scheduled at 4 of 14 restaurants."
    },
    month: {
      v: "25.1%",
      d: "+0.5",
      region: "−0.6",
      system: "−1.1",
      target: "24.6%",
      headline: "Trending back to target",
      why: "Down from 26.8% earlier in May."
    },
    ytd: {
      v: "25.4%",
      d: "+0.8",
      region: "−0.5",
      system: "−1.0",
      target: "24.6%",
      headline: "Above target YTD",
      why: "Q1 ran high during winter weather; trending down since."
    }
  }, {
    id: 7,
    k: "Star rating",
    dir: "up",
    action: "See reviews by restaurant",
    today: {
      v: "4.6",
      d: "+0.1",
      region: "+0.2",
      system: "+0.3",
      target: "4.5",
      headline: "Above target",
      why: "Recent reviews praise speed and friendliness. #1208 added five new 5-star reviews.",
      breakdown: [["Google", "4.7"], ["Yelp", "4.4"], ["App", "4.6"]]
    },
    week: {
      v: "4.5",
      d: "on target",
      region: "+0.1",
      system: "+0.2",
      target: "4.5",
      headline: "Right on target",
      why: "Accuracy complaints down vs last week."
    },
    month: {
      v: "4.5",
      d: "+0.1",
      region: "+0.1",
      system: "+0.2",
      target: "4.5",
      headline: "At target",
      why: "Holding at target as new crews settle in."
    },
    ytd: {
      v: "4.4",
      d: "+0.2",
      region: "0.0",
      system: "+0.1",
      target: "4.5",
      headline: "Just under target YTD",
      why: "YoY rating climbing as consistency improves."
    }
  }, {
    id: 5,
    k: "REV",
    dir: "up",
    action: "See REV score detail",
    today: {
      v: "89",
      d: "+3",
      region: "+2",
      system: "+4",
      target: "85",
      headline: "Above standard",
      why: "Guest experience scores up — speed of service and accuracy both improved this morning.",
      breakdown: [["Speed", "92"], ["Accuracy", "88"], ["Cleanliness", "87"]]
    },
    week: {
      v: "88",
      d: "+2",
      region: "+2",
      system: "+3",
      target: "85",
      headline: "Above standard",
      why: "Consistent scores led by order accuracy."
    },
    month: {
      v: "87",
      d: "+1",
      region: "+1",
      system: "+3",
      target: "85",
      headline: "Above standard",
      why: "Trending up as new crews ramp on standards."
    },
    ytd: {
      v: "86",
      d: "+2",
      region: "+1",
      system: "+2",
      target: "85",
      headline: "Above standard YTD",
      why: "Steady YoY improvement in guest experience."
    }
  }],
  taskTypes: {
    schedule: {
      label: "Schedule",
      icon: "CalendarDays"
    },
    inventory: {
      label: "Inventory",
      icon: "Boxes"
    },
    menu: {
      label: "Menu",
      icon: "UtensilsCrossed"
    }
  },
  people: {
    M: {
      name: "Maria",
      color: "hsl(var(--avatar-1))"
    },
    D: {
      name: "Devon",
      color: "hsl(var(--avatar-2))",
      photo: "https://i.pravatar.cc/120?img=12"
    },
    R: {
      name: "Riley",
      color: "hsl(var(--avatar-3))",
      photo: "https://i.pravatar.cc/120?img=47"
    }
  },
  tasks: [{
    id: 2,
    who: "M",
    type: "menu",
    t: "Approve new pricing recs · 6 restaurants",
    w: "+$0.18 / footlong · +$2.4k/wk",
    store: "CT East · 6 restaurants",
    due: "Today 5pm",
    hot: false,
    a: "Review",
    stats: [["Lift / footlong", "+$0.18"], ["Weekly impact", "+$2.4k"]],
    bars: [42, 46, 50, 55, 58, 62, 66, 70],
    barLabel: "Projected weekly sales lift"
  }, {
    id: 3,
    who: "M",
    type: "menu",
    t: "Opt into BOGO discount · Window 8",
    w: "Promo window 8 · est. +$3.1k/wk",
    store: "Portfolio · 14 restaurants",
    due: "Fri",
    hot: false,
    a: "Opt in",
    stats: [["Promo window", "8"], ["Est. weekly", "+$3.1k"]],
    bars: [30, 38, 44, 52, 60, 66, 72, 78],
    barLabel: "Comparable promo performance"
  }, {
    id: 4,
    who: "D",
    type: "schedule",
    t: "Send Anna home (labor over)",
    w: "Saves ~$48 today",
    store: "#1208 Stamford",
    due: "Today 12p",
    hot: true,
    a: "Send home",
    stats: [["Saves today", "~$48"], ["Labor vs plan", "+18%"]],
    bars: [22, 24, 26, 28, 30, 31, 30, 27],
    barLabel: "Labor vs forecast · today"
  }, {
    id: 5,
    who: "D",
    type: "schedule",
    t: "Fill opening shift at #1146",
    w: "Forecast says +1 needed",
    store: "#1146 Bristol",
    due: "Wed",
    hot: false,
    a: "Fill shift",
    stats: [["Forecast gap", "+1"], ["Coverage", "82%"]],
    bars: [60, 64, 70, 74, 80, 78, 76, 72],
    barLabel: "Forecast coverage · this week"
  }, {
    id: 1,
    who: "R",
    type: "inventory",
    t: "Reorder tomatoes (14 cases)",
    w: "Will stock-out Thu lunch otherwise",
    store: "Portfolio · 7 restaurants",
    due: "Today 4pm",
    hot: true,
    a: "Place order",
    order: true
  }],
  tomatoOrder: {
    vendor: "Sysco Northeast",
    cutoff: "Today · 4:00 PM (4h 18m away)",
    delivery: "Wed · 6–9 AM",
    unitCost: 24.50,
    unit: "case",
    confidence: 92,
    allocation: [{
      store: "#4421 Hartford",
      cases: 3,
      current: 1,
      cover: "covers 5 days"
    }, {
      store: "#552 Bridgeport",
      cases: 3,
      current: 1,
      cover: "covers 5 days"
    }, {
      store: "#1208 Stamford",
      cases: 2,
      current: 0,
      cover: "covers 4 days"
    }, {
      store: "#732 New Haven",
      cases: 2,
      current: 1,
      cover: "covers 4 days"
    }, {
      store: "#118 Waterbury",
      cases: 2,
      current: 0,
      cover: "covers 4 days"
    }, {
      store: "#902 Norwalk",
      cases: 1,
      current: 1,
      cover: "covers 4 days"
    }, {
      store: "#311 Danbury",
      cases: 1,
      current: 0,
      cover: "covers 4 days"
    }]
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rise-home/data.js", error: String((e && e.message) || e) }); }

// ui_kits/rise-insights/FlashReport.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// RISE Insights · Flash Report — the filter-aware report body.
(function () {
  const DS = window.RISEDesignSystem_6a845d;
  const {
    Panel,
    Kpi,
    Donut,
    LineChart,
    ChartLegend,
    StackedMeter,
    Button,
    Icon,
    AskModal,
    CommentSheet
  } = DS;
  const D = window.RISE_INSIGHTS;
  const usd = n => "$" + n.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  // Every panel owns its own Ask RISE / comment state, exactly as in the source product.
  function RisePanel(props) {
    const [ask, setAsk] = React.useState(false);
    const [sheet, setSheet] = React.useState(false);
    const [comments, setComments] = React.useState([]);
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Panel, _extends({}, props, {
      replies: comments.length,
      onAsk: () => setAsk(true),
      onComment: () => setSheet(true),
      onTakeawayClick: () => setSheet(true),
      onDownload: () => {}
    })), /*#__PURE__*/React.createElement(AskModal, {
      open: ask,
      onClose: () => setAsk(false),
      title: props.title,
      sub: props.sub,
      context: props.takeaway
    }), /*#__PURE__*/React.createElement(CommentSheet, {
      open: sheet,
      onClose: () => setSheet(false),
      title: props.title,
      sub: props.sub,
      takeaway: props.takeaway,
      tone: props.tone,
      chart: props.children,
      comments: comments,
      onPost: body => setComments(c => c.concat({
        body: body,
        author: "Maria",
        when: "just now"
      })),
      team: D.team
    }));
  }
  function GroupTable({
    rows,
    columns,
    format
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        overflowX: "auto"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        fontSize: 12,
        borderCollapse: "collapse"
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        fontSize: 10,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        color: "hsl(var(--muted-foreground))"
      }
    }, /*#__PURE__*/React.createElement("th", {
      style: {
        textAlign: "left",
        fontWeight: 600,
        padding: "6px 8px"
      }
    }, "Unit"), columns.map(c => /*#__PURE__*/React.createElement("th", {
      key: c[0],
      style: {
        textAlign: "right",
        fontWeight: 600,
        padding: "6px 8px",
        whiteSpace: "nowrap"
      }
    }, c[0])))), /*#__PURE__*/React.createElement("tbody", null, rows.map(([name, w]) => /*#__PURE__*/React.createElement("tr", {
      key: name,
      style: {
        borderTop: "1px solid hsl(var(--border))"
      }
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "6px 8px",
        fontWeight: 500,
        whiteSpace: "nowrap"
      }
    }, name), columns.map(c => /*#__PURE__*/React.createElement("td", {
      key: c[0],
      style: {
        padding: "6px 8px",
        textAlign: "right",
        fontVariantNumeric: "tabular-nums"
      }
    }, format(c[1] * w))))))));
  }
  function HeatMap() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        overflowX: "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        minWidth: 480,
        display: "grid",
        gridTemplateColumns: "96px repeat(7,1fr)",
        gap: 4
      }
    }, /*#__PURE__*/React.createElement("div", null), D.days.map(d => /*#__PURE__*/React.createElement("div", {
      key: d,
      style: {
        fontSize: 10,
        fontWeight: 600,
        color: "hsl(var(--muted-foreground))",
        textAlign: "center"
      }
    }, d)), D.heat.map(([dp, row]) => /*#__PURE__*/React.createElement(React.Fragment, {
      key: dp
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "hsl(var(--muted-foreground))",
        display: "flex",
        alignItems: "center"
      }
    }, dp), row.map((v, c) => /*#__PURE__*/React.createElement("div", {
      key: c,
      title: dp + " · " + Math.round(v * 100) + "%",
      style: {
        height: 28,
        borderRadius: 4,
        background: "hsl(var(--primary) / " + v + ")"
      }
    }))))));
  }
  function FlashReport({
    filters,
    basis
  }) {
    const applied = filters.applied || [],
      vals = filters.vals || {};
    const selOf = k => applied.indexOf(k) > -1 ? vals[k] || [] : [];
    const chSel = selOf("channel"),
      dpSel = selOf("daypart"),
      rsSel = selOf("restaurant");
    const sumShare = (sel, map) => sel.length === 0 ? 1 : sel.reduce((s, k) => s + (map[k] || 0), 0);
    const dateF = D.dateFactor[filters.date] || 1;
    const rsFrac = rsSel.length === 0 ? 1 : Math.max(rsSel.length / 14, 0.04);
    const chFrac = sumShare(chSel, D.channelShare),
      dpFrac = sumShare(dpSel, D.daypartShare);
    const mult = dateF * rsFrac * chFrac * dpFrac;
    const grp = filters.groupBy && filters.groupBy !== "none" ? filters.groupBy : null;
    const units = grp ? D.groupUnits[grp] : null;
    const series = D.sales7.map(v => v * mult),
      comparison = D.avg12.map(v => v * mult);
    const dayparts = D.dayparts.filter(d => dpSel.length === 0 || dpSel.indexOf(d[1]) > -1).map(d => [d[0], d[2] * dateF * rsFrac * chFrac, d[3], d[4]]);
    const channels = D.channels.filter(c => chSel.length === 0 || chSel.indexOf(c[1]) > -1).map(c => [c[0], c[2] * dateF * rsFrac * dpFrac, c[3], c[4]]);
    const variance = D.cash.actual - D.cash.expected;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4,1fr)",
        gridAutoRows: "1fr",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Kpi, {
      label: "Total Sales",
      value: usd(6820 * mult),
      dir: "up",
      mag: "+3.2%"
    }), /*#__PURE__*/React.createElement(Kpi, {
      label: "Avg Ticket",
      value: usd(8.40),
      dir: "up",
      mag: "+$0.20"
    }), /*#__PURE__*/React.createElement(Kpi, {
      label: "Transactions",
      value: Math.round(812 * mult).toLocaleString(),
      dir: "up",
      mag: "+5%"
    }), /*#__PURE__*/React.createElement(Kpi, {
      label: "Hours vs Target",
      value: "+11%",
      dir: "up",
      mag: "+11%",
      good: false
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "2fr 1fr",
        gap: 16,
        alignItems: "stretch"
      }
    }, /*#__PURE__*/React.createElement(RisePanel, {
      title: "Sales vs. 12-Week Avg",
      sub: "Today vs. same-day 12-week average",
      takeaway: "Sun is pacing 7% below your 12-week average. Move one Sun-evening closer shift to Fri 5\u20138pm to match demand."
    }, units ? /*#__PURE__*/React.createElement(GroupTable, {
      rows: units,
      columns: D.days.map((d, i) => [d, series[i]]),
      format: usd
    }) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(LineChart, {
      series: series,
      comparison: comparison,
      labels: D.days,
      dates: D.dayDates,
      basis: basis
    }), /*#__PURE__*/React.createElement(ChartLegend, {
      seriesLabel: "This week",
      comparisonLabel: basis === "PY" ? "prior year" : basis === "Prior" ? "prior period" : "12-wk avg"
    }))), /*#__PURE__*/React.createElement(RisePanel, {
      title: "Footlong vs. 6-Inch",
      sub: "Carrier mix \xB7 share of sandwiches today",
      takeaway: "Footlongs are 64% of sandwiches \u2014 up 2 pts vs. your 12-week average. Keep footlong combos front-and-centre on the digital menu to protect average ticket."
    }, units ? /*#__PURE__*/React.createElement(GroupTable, {
      rows: units,
      columns: D.carriers.map(c => [c[0], c[1]]),
      format: n => Math.round(n).toLocaleString()
    }) : /*#__PURE__*/React.createElement(StackedMeter, {
      data: D.carriers
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 16,
        alignItems: "stretch"
      }
    }, /*#__PURE__*/React.createElement(RisePanel, {
      title: "Daypart Breakdown",
      sub: "Sales & share of day",
      takeaway: "Lunch drives 43.7% of sales. Put your strongest artist on the 11am\u20131pm rush \u2014 your highest-leverage hour."
    }, units ? /*#__PURE__*/React.createElement(GroupTable, {
      rows: units,
      columns: dayparts.map(d => [d[0], d[1]]),
      format: usd
    }) : /*#__PURE__*/React.createElement(Donut, {
      data: dayparts
    })), /*#__PURE__*/React.createElement(RisePanel, {
      title: "Channel Mix",
      sub: "In-store / 1P Digital / 3PD / Catering",
      takeaway: "3PD is 16.6% of sales; after ~30% fees that's ~$790 net. Nudge guests to in-app pickup to recover margin."
    }, units ? /*#__PURE__*/React.createElement(GroupTable, {
      rows: units,
      columns: channels.map(c => [c[0], c[1]]),
      format: usd
    }) : /*#__PURE__*/React.createElement(Donut, {
      data: channels
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 16,
        alignItems: "stretch"
      }
    }, /*#__PURE__*/React.createElement(RisePanel, {
      title: "Daypart Heat Map",
      sub: "Sales intensity \xB7 daypart \xD7 day",
      takeaway: "Lunch Fri\u2013Sat is your peak; Saturday lunch runs hottest. Protect that window's staffing and prep levels."
    }, /*#__PURE__*/React.createElement(HeatMap, null), /*#__PURE__*/React.createElement("a", {
      href: "#",
      style: {
        marginTop: 12,
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        height: 36,
        borderRadius: "var(--radius-md)",
        border: "1px solid hsl(var(--input))",
        background: "hsl(var(--background))",
        padding: "0 16px",
        fontSize: 14,
        fontWeight: 500,
        boxShadow: "var(--shadow-sm)",
        textDecoration: "none",
        color: "hsl(var(--foreground))"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "CalendarClock",
      size: 16
    }), "View hours opportunity worksheet", /*#__PURE__*/React.createElement(Icon, {
      name: "ArrowRight",
      size: 14
    }))), /*#__PURE__*/React.createElement(RisePanel, {
      title: "Add-on Attach Trend",
      sub: "Items per transaction \xB7 weekly",
      takeaway: "Attach climbed from 1.5 to 1.9 over 12 weeks \u2014 above your 1.7 target. The combo prompt is doing its job; keep it on."
    }, /*#__PURE__*/React.createElement(LineChart, {
      series: D.attach,
      comparison: D.attachTarget,
      labels: D.attachWeeks,
      basis: "target 1.7",
      format: v => v.toFixed(2)
    }), /*#__PURE__*/React.createElement(ChartLegend, {
      seriesLabel: "Attach rate",
      comparisonLabel: "Target 1.7"
    }))), /*#__PURE__*/React.createElement(RisePanel, {
      title: "Exceptions Summary",
      sub: "Tap a type to open Loss Prevention",
      tone: "warn",
      takeaway: "Corrections are at 6 today \u2014 above your warning threshold of 5. One clerk accounts for 4 of them; review the whole-order corrections log for the 6\u20138pm shift."
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4,1fr)",
        gap: 12
      }
    }, D.exceptions.map(([name, count, st]) => /*#__PURE__*/React.createElement("a", {
      key: name,
      href: "#",
      style: {
        borderRadius: "var(--radius-lg)",
        padding: 12,
        textDecoration: "none",
        color: "inherit",
        border: "1px solid " + (st === "warn" ? "hsl(var(--brand-yellow) / .5)" : "hsl(var(--border))"),
        background: st === "warn" ? "hsl(var(--brand-yellow) / .05)" : "hsl(var(--card))"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "hsl(var(--muted-foreground))"
      }
    }, name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 24,
        fontWeight: 800,
        fontVariantNumeric: "tabular-nums",
        marginTop: 2,
        color: st === "warn" ? "hsl(var(--brand-yellow))" : "hsl(var(--foreground))"
      }
    }, count))))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 16,
        alignItems: "stretch"
      }
    }, /*#__PURE__*/React.createElement(RisePanel, {
      title: "Tips Summary",
      takeaway: "Tips per transaction is up $0.05 vs. 12-week average \u2014 the new prompt screen is working. Keep it enabled across all terminals."
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 12
      }
    }, [["Total Tips", usd(D.tips.total)], ["Tips / Transaction", usd(D.tips.perTxn)]].map(([l, v]) => /*#__PURE__*/React.createElement("div", {
      key: l,
      style: {
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--border))",
        background: "hsl(var(--card))",
        padding: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "hsl(var(--muted-foreground))"
      }
    }, l), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 20,
        fontWeight: 800,
        fontVariantNumeric: "tabular-nums",
        marginTop: 2
      }
    }, v))))), /*#__PURE__*/React.createElement(RisePanel, {
      title: "Cash Reconciliation",
      tone: "warn",
      takeaway: "Cash is $13.50 short \u2014 above your $10 alert threshold. Re-count the closing drawer and review the 8\u201310pm voids before deposit."
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(3,1fr)",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--border))",
        background: "hsl(var(--card))",
        padding: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "hsl(var(--muted-foreground))"
      }
    }, "Expected"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 800,
        fontVariantNumeric: "tabular-nums",
        marginTop: 2,
        whiteSpace: "nowrap"
      }
    }, usd(D.cash.expected))), /*#__PURE__*/React.createElement("div", {
      style: {
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--border))",
        background: "hsl(var(--card))",
        padding: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: "hsl(var(--muted-foreground))"
      }
    }, "Actual"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 800,
        fontVariantNumeric: "tabular-nums",
        marginTop: 2,
        whiteSpace: "nowrap"
      }
    }, usd(D.cash.actual))), /*#__PURE__*/React.createElement("div", {
      style: {
        borderRadius: "var(--radius-lg)",
        border: "1px solid hsl(var(--destructive) / .4)",
        background: "hsl(var(--destructive) / .05)",
        padding: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        fontWeight: 600,
        color: "hsl(var(--destructive))"
      }
    }, "Variance"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 800,
        fontVariantNumeric: "tabular-nums",
        marginTop: 2,
        color: "hsl(var(--destructive))",
        whiteSpace: "nowrap"
      }
    }, "\u2212", usd(Math.abs(variance))))))));
  }
  window.RiseFlashReport = FlashReport;
  window.RisePanel = RisePanel;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rise-insights/FlashReport.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rise-insights/InsightsScreen.jsx
try { (() => {
// RISE Insights — shell, page head, filter bar and report switching.
(function () {
  const DS = window.RISEDesignSystem_6a845d;
  const {
    Shell,
    PageContainer,
    PageHead,
    FilterBar,
    Button,
    Icon,
    DropdownMenu,
    DropdownMenuItem,
    Card,
    CardContent,
    Panel
  } = DS;
  const D = window.RISE_INSIGHTS;
  const RisePanel = window.RisePanel,
    FlashReport = window.RiseFlashReport;
  const usd = n => "$" + n.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  function GroupedBreakdown({
    dim
  }) {
    const units = D.groupUnits[dim];
    if (!units) return null;
    const totals = units.map(([n, w]) => [n, 438600 * w]);
    const max = Math.max.apply(null, totals.map(t => t[1]));
    const label = dim === "group" ? "Restaurant Group" : "Restaurant";
    return /*#__PURE__*/React.createElement(RisePanel, {
      title: "Net Sales by " + label,
      sub: "Grouped view \xB7 this period",
      takeaway: "Grouped by " + label.toLowerCase() + ". " + totals[0][0] + " leads at " + usd(totals[0][1]) + "; the lowest trails by " + Math.round((1 - totals[totals.length - 1][1] / totals[0][1]) * 100) + "%."
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 10
      }
    }, totals.map(([n, v], i) => /*#__PURE__*/React.createElement("div", {
      key: n,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        fontSize: 13
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 20,
        color: "hsl(var(--muted-foreground))",
        fontVariantNumeric: "tabular-nums"
      }
    }, i + 1), /*#__PURE__*/React.createElement("span", {
      style: {
        width: 160,
        fontWeight: 500,
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap"
      }
    }, n), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 12,
        borderRadius: "var(--radius-full)",
        background: "hsl(var(--muted))",
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: "100%",
        background: "hsl(var(--primary))",
        width: v / max * 100 + "%"
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        width: 88,
        textAlign: "right",
        fontWeight: 700,
        fontVariantNumeric: "tabular-nums"
      }
    }, usd(v))))));
  }
  function Scaffold({
    name
  }) {
    return /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardContent, {
      style: {
        padding: "64px 24px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 40,
        height: 40,
        borderRadius: "var(--radius-full)",
        background: "hsl(var(--muted))",
        display: "grid",
        placeItems: "center"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "LineChart",
      size: 20,
      color: "hsl(var(--muted-foreground))"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        fontWeight: 600
      }
    }, name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "hsl(var(--muted-foreground))",
        maxWidth: 320
      }
    }, "This report is next in the build queue. Flash Report is live \u2014 pick it from the Insights nav.")));
  }
  function InsightsScreen() {
    const [active, setActive] = React.useState("flash");
    const [cmp, setCmp] = React.useState("12wa");
    const [filters, setFilters] = React.useState({
      date: "today",
      applied: [],
      vals: {},
      groupBy: "none"
    });
    const title = (D.reports.find(([k]) => k === active) || ["", "Insights"])[1];
    const grouped = filters.groupBy && filters.groupBy !== "none";
    return /*#__PURE__*/React.createElement(Shell, {
      active: active,
      onSelect: setActive
    }, /*#__PURE__*/React.createElement(PageContainer, null, /*#__PURE__*/React.createElement(PageHead, {
      eyebrow: "Insights",
      title: title,
      action: /*#__PURE__*/React.createElement(DropdownMenu, {
        align: "end",
        trigger: /*#__PURE__*/React.createElement(Button, {
          variant: "outline"
        }, /*#__PURE__*/React.createElement(Icon, {
          name: "Download",
          size: 16
        }), "Export")
      }, /*#__PURE__*/React.createElement(DropdownMenuItem, {
        icon: "FileText"
      }, "Export to PDF"), /*#__PURE__*/React.createElement(DropdownMenuItem, {
        icon: "FileSpreadsheet"
      }, "Export to Excel"))
    }), /*#__PURE__*/React.createElement(FilterBar, {
      date: filters.date,
      onDateChange: d => setFilters(f => Object.assign({}, f, {
        date: d
      })),
      dateOptions: D.dates,
      filterDefs: D.filterDefs,
      applied: filters.applied,
      values: filters.vals,
      onAdd: k => setFilters(f => Object.assign({}, f, {
        applied: f.applied.concat(k),
        vals: Object.assign({}, f.vals, {
          [k]: []
        })
      })),
      onRemove: k => setFilters(f => Object.assign({}, f, {
        applied: f.applied.filter(x => x !== k)
      })),
      onValuesChange: (k, arr) => setFilters(f => Object.assign({}, f, {
        vals: Object.assign({}, f.vals, {
          [k]: arr
        })
      })),
      groupBy: filters.groupBy,
      onGroupByChange: v => setFilters(f => Object.assign({}, f, {
        groupBy: v
      })),
      groupByOptions: D.groupBy,
      compare: cmp,
      onCompareChange: setCmp,
      compareOptions: D.compare
    }), grouped && active !== "flash" ? /*#__PURE__*/React.createElement(GroupedBreakdown, {
      dim: filters.groupBy
    }) : null, active === "flash" ? /*#__PURE__*/React.createElement(FlashReport, {
      filters: filters,
      basis: D.basis[cmp]
    }) : /*#__PURE__*/React.createElement(Scaffold, {
      name: title
    })));
  }
  window.RiseInsightsScreen = InsightsScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rise-insights/InsightsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rise-insights/data.js
try { (() => {
// Fixtures for the RISE Insights kit — lifted from the prototype's rise-flash.jsx.
window.RISE_INSIGHTS = {
  reports: [["flash", "Flash Report"], ["pnl", "Weekly P&L"], ["labor", "Labor Summary"], ["loss", "Loss Prevention"], ["mine", "Maria's Dashboard"]],
  dates: [["today", "Today"], ["yest", "Yesterday"], ["wtd", "Week to date"]],
  groupBy: [["none", "No grouping"], ["group", "Restaurant Group"], ["restaurant", "Restaurant"]],
  compare: [["12wa", "12-week avg"], ["prior", "Prior period"], ["py", "Prior year"]],
  basis: {
    "12wa": "12WA",
    prior: "Prior",
    py: "PY"
  },
  dateFactor: {
    today: 1,
    yest: 0.96,
    wtd: 5.8
  },
  filterDefs: {
    channel: {
      label: "Channel",
      icon: "Store",
      options: [["instore", "In-Restaurant"], ["1pd", "1P Digital"], ["3pd", "3PD"], ["catering", "Catering"]]
    },
    restaurant: {
      label: "Restaurant",
      icon: "MapPin",
      options: [["4421", "#4421 Hartford"], ["552", "#552 Bridgeport"], ["1208", "#1208 Stamford"], ["732", "#732 New Haven"], ["1146", "#1146 Bristol"], ["118", "#118 Waterbury"], ["902", "#902 Norwalk"], ["311", "#311 Danbury"]]
    },
    daypart: {
      label: "Daypart",
      icon: "Clock",
      options: [["breakfast", "Breakfast"], ["lunch", "Lunch"], ["pm", "PM Snack"], ["dinner", "Dinner"], ["evening", "Evening"], ["late", "Late Night"]]
    }
  },
  channelShare: {
    instore: 0.566,
    "1pd": 0.199,
    "3pd": 0.152,
    catering: 0.083
  },
  daypartShare: {
    breakfast: 0.182,
    lunch: 0.437,
    pm: 0.106,
    dinner: 0.196,
    evening: 0.06,
    late: 0.019
  },
  days: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
  dayDates: ["Jun 9", "Jun 10", "Jun 11", "Jun 12", "Jun 13", "Jun 14", "Jun 15"],
  sales7: [2480, 2310, 2640, 2720, 3120, 3580, 2410],
  avg12: [2400, 2450, 2500, 2700, 3050, 3400, 2600],
  dayparts: [["Breakfast", "breakfast", 1240.50, "hsl(var(--chart-daypart-1))", "↑ 3%"], ["Lunch", "lunch", 2980.75, "hsl(var(--chart-daypart-2))", "↑ 1%"], ["PM Snack", "pm", 720.25, "hsl(var(--chart-daypart-3))", "↓ 2%"], ["Dinner", "dinner", 1340.00, "hsl(var(--chart-daypart-4))", "↑ 1%"], ["Evening", "evening", 410.50, "hsl(var(--chart-daypart-5))", "↓ 1%"], ["Late Night", "late", 128.00, "hsl(var(--chart-daypart-6))", "↑ 5%"]],
  channels: [["In-store", "instore", 4210.25, "hsl(var(--chart-channel-1))", "↑ 4%"], ["1P Digital", "1pd", 1480.50, "hsl(var(--chart-channel-2))", "↑ 8%"], ["3PD", "3pd", 1129.25, "hsl(var(--chart-channel-3))", "↓ 2%"], ["Catering", "catering", 620.00, "hsl(var(--chart-channel-4))", "↑ 12%"]],
  carriers: [["Footlong", 520, "hsl(var(--primary))", "↑ 2%"], ["6-Inch", 286, "hsl(var(--brand-yellow))", "↓ 1%"], ["Other", 61, "hsl(var(--chart-neutral))", "↑ 1%"]],
  exceptions: [["Voids", 2, "ok"], ["Corrections", 6, "warn"], ["Price overrides", 1, "ok"], ["Refunds", 0, "ok"]],
  heat: [["Breakfast", [.3, .35, .4, .38, .5, .6, .45]], ["Lunch", [.7, .75, .8, .78, .9, 1, .7]], ["PM Snack", [.25, .3, .32, .3, .4, .5, .35]], ["Dinner", [.5, .55, .6, .58, .7, .85, .55]], ["Evening", [.15, .18, .2, .22, .3, .4, .25]], ["Late", [.05, .06, .08, .1, .15, .2, .12]]],
  attachWeeks: ["W1", "W2", "W3", "W4", "W5", "W6", "W7", "W8", "W9", "W10", "W11", "W12"],
  attach: [1.5, 1.6, 1.6, 1.7, 1.7, 1.8, 1.7, 1.8, 1.8, 1.9, 1.8, 1.9],
  attachTarget: [1.7, 1.7, 1.7, 1.7, 1.7, 1.7, 1.7, 1.7, 1.7, 1.7, 1.7, 1.7],
  cash: {
    expected: 1840.00,
    actual: 1826.50
  },
  tips: {
    total: 184.50,
    perTxn: 0.23
  },
  team: [["Maya", "Maya Chen"], ["Devin", "Devin Park"], ["Sara", "Sara Lopez"], ["Marcus", "Marcus Webb"], ["Priya", "Priya Nair"]],
  groupUnits: {
    group: [["NYC Portfolio", .42], ["CT Portfolio", .33], ["Unassigned", .25]],
    restaurant: [["#4421 Hartford", .18], ["#552 Bridgeport", .16], ["#1208 Stamford", .15], ["#732 New Haven", .14], ["#1146 Bristol", .13], ["#118 Waterbury", .12], ["#902 Norwalk", .12]]
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rise-insights/data.js", error: String((e && e.message) || e) }); }

__ds_ns.BrandMark = __ds_scope.BrandMark;

__ds_ns.BrandLockup = __ds_scope.BrandLockup;

__ds_ns.SparkMark = __ds_scope.SparkMark;

__ds_ns.CustomDateButton = __ds_scope.CustomDateButton;

__ds_ns.FilterBar = __ds_scope.FilterBar;

__ds_ns.GroupByChip = __ds_scope.GroupByChip;

__ds_ns.MiniCalendar = __ds_scope.MiniCalendar;

__ds_ns.MultiFilterChip = __ds_scope.MultiFilterChip;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Separator = __ds_scope.Separator;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.Delta = __ds_scope.Delta;

__ds_ns.Donut = __ds_scope.Donut;

__ds_ns.Kpi = __ds_scope.Kpi;

__ds_ns.LineChart = __ds_scope.LineChart;

__ds_ns.ChartLegend = __ds_scope.ChartLegend;

__ds_ns.RankCard = __ds_scope.RankCard;

__ds_ns.StackedMeter = __ds_scope.StackedMeter;

__ds_ns.TaskRow = __ds_scope.TaskRow;

__ds_ns.Trend = __ds_scope.Trend;

__ds_ns.RISE_REPORTS = __ds_scope.RISE_REPORTS;

__ds_ns.RISE_CATEGORIES = __ds_scope.RISE_CATEGORIES;

__ds_ns.RailRow = __ds_scope.RailRow;

__ds_ns.RailChild = __ds_scope.RailChild;

__ds_ns.Rail = __ds_scope.Rail;

__ds_ns.Shell = __ds_scope.Shell;

__ds_ns.PageContainer = __ds_scope.PageContainer;

__ds_ns.RISE_STORE_GROUPS = __ds_scope.RISE_STORE_GROUPS;

__ds_ns.StorePicker = __ds_scope.StorePicker;

__ds_ns.Topbar = __ds_scope.Topbar;

__ds_ns.AskModal = __ds_scope.AskModal;

__ds_ns.CommentSheet = __ds_scope.CommentSheet;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.DialogHeader = __ds_scope.DialogHeader;

__ds_ns.DialogTitle = __ds_scope.DialogTitle;

__ds_ns.DialogDescription = __ds_scope.DialogDescription;

__ds_ns.DropdownMenu = __ds_scope.DropdownMenu;

__ds_ns.DropdownMenuItem = __ds_scope.DropdownMenuItem;

__ds_ns.DropdownMenuLabel = __ds_scope.DropdownMenuLabel;

__ds_ns.Sheet = __ds_scope.Sheet;

__ds_ns.SheetHeader = __ds_scope.SheetHeader;

__ds_ns.SheetBody = __ds_scope.SheetBody;

__ds_ns.SheetFooter = __ds_scope.SheetFooter;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardContent = __ds_scope.CardContent;

__ds_ns.InsightCard = __ds_scope.InsightCard;

__ds_ns.NextRightThing = __ds_scope.NextRightThing;

__ds_ns.PageHead = __ds_scope.PageHead;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.ScaffoldFrame = __ds_scope.ScaffoldFrame;

})();
